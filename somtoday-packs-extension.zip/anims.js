// SOMtoday Packs: bibliotheek met 58 3D "walkout"-animaties + 12 onthulling-effecten.
// Alles is canvas met een eigen perspectiefprojectie (geen libraries). content.js gebruikt SC_ANIMS.
(() => {
'use strict';
const TAU = Math.PI * 2, PHI = (1 + Math.sqrt(5)) / 2, R = Math.random, rr = (a, b) => a + R() * (b - a), cl = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v), pick = a => a[(R() * a.length) | 0], mod = (a, n) => ((a % n) + n) % n;
const A = (c, al) => c + Math.round(cl(al) * 255).toString(16).padStart(2, '0');
const hx = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
const mix = (a, b, t) => { const p = hx(a), q = hx(b); return '#' + p.map((v, i) => Math.round(v + (q[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
const hsl = (h, s, l) => { s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return '#' + [f(0), f(8), f(4)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join(''); };
const rot = (v, ay, ax, az = 0) => { let X = v[0], Y = v[1], Z = v[2], c = Math.cos(ay), s = Math.sin(ay), t = X * c + Z * s; Z = -X * s + Z * c; X = t; c = Math.cos(ax); s = Math.sin(ax); t = Y * c - Z * s; Z = Y * s + Z * c; Y = t; if (az) { c = Math.cos(az); s = Math.sin(az); t = X * c - Y * s; Y = X * s + Y * c; X = t; } return [X, Y, Z]; };
// lijn door geprojecteerde punten (null = onderbreking)
const stroke3 = (e, pts, close) => { const x = e.x; let go = false; x.beginPath(); for (const p of pts) { if (!p) { go = false; continue; } go ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]); go = true; } if (close) x.closePath(); x.stroke(); };
const path = (x, pts) => { x.beginPath(); pts.forEach((p, k) => (k ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]))); };

// ---------- geometrie: tetra, kubus, octaëder, icosaëder, dodecaëder en een echte voetbal (afgeknotte icosaëder) ----------
const perm3 = (a, b, c) => { const out = []; [[a, b, c], [c, a, b], [b, c, a]].forEach(t => { const s = t.map(v => (v === 0 ? [0] : [v, -v])); s[0].forEach(X => s[1].forEach(Y => s[2].forEach(Z => out.push([X, Y, Z])))); }); return out; };
const GEO = (() => {
  const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);
  const edges = (v, d) => { const e = []; for (let i = 0; i < v.length; i++) for (let j = i + 1; j < v.length; j++) if (Math.abs(dist(v[i], v[j]) - d) < .02) e.push([i, j]); return e; };
  const norm = v => v.map(p => { const m = Math.hypot(p[0], p[1], p[2]); return [p[0] / m, p[1] / m, p[2] / m]; });
  const mk = (v, d) => ({ e: edges(v, d), v: norm(v) });
  const cubeV = []; for (let i = 0; i < 8; i++) cubeV.push([i & 1 ? 1 : -1, i & 2 ? 1 : -1, i & 4 ? 1 : -1]);
  const icoV = perm3(0, 1, PHI), dodV = cubeV.concat(perm3(0, 1 / PHI, PHI)), ballV = perm3(0, 1, 3 * PHI).concat(perm3(1, 2 + PHI, 2 * PHI), perm3(PHI, 2, 2 * PHI + 1));
  const ball = mk(ballV, 2), ico = norm(icoV), dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  ball.f = ico.map(d => { const t = Math.abs(d[0]) < .9 ? [1, 0, 0] : [0, 1, 0], u0 = cross(d, t), um = Math.hypot(...u0), u = u0.map(c => c / um), v = cross(d, u);
    const idx = ball.v.map((p, i) => [dot(p, d), i]).sort((a, b) => b[0] - a[0]).slice(0, 5).map(a => a[1]); idx.sort((a, b) => Math.atan2(dot(ball.v[a], v), dot(ball.v[a], u)) - Math.atan2(dot(ball.v[b], v), dot(ball.v[b], u))); return { n: d, i: idx }; });
  return { tetra: mk([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], 2 * Math.SQRT2), cube: mk(cubeV, 2), octa: mk([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], Math.SQRT2), icosa: mk(icoV, 2), dodeca: mk(dodV, 2 / PHI), football: ball };
})();
// de voetbal: zwarte vijfhoeken, gloeiende naden, dieptegevoel
const ball = (e, X, Y, Z, s, ay, ax, al) => {
  const x = e.x, G = GEO.football, P = G.v.map(v => { const q = rot(v, ay, ax); return { q, p: e.pr(X + q[0] * s, Y + q[1] * s, Z + q[2] * s) }; }), c = e.pr(X, Y, Z); if (!c) return;
  x.save(); const r = c[2] * s, g = x.createRadialGradient(c[0] - r * .3, c[1] - r * .3, r * .1, c[0], c[1], r * 1.05); g.addColorStop(0, A('#ffffff', .22 * al)); g.addColorStop(.7, A(e.c1, .1 * al)); g.addColorStop(1, A(e.c1, 0)); x.fillStyle = g; x.beginPath(); x.arc(c[0], c[1], r * 1.05, 0, TAU); x.fill();
  G.f.forEach(f => { const n = rot(f.n, ay, ax); const pts = f.i.map(i => P[i].p); if (pts.some(p => !p)) return; path(x, pts); x.closePath(); if (n[2] < .2) { x.fillStyle = A('#000000', .7 * al); x.fill(); } });
  x.strokeStyle = A('#ffffff', .85 * al); x.lineWidth = cl(r * .012, 1, 3); x.beginPath(); G.e.forEach(([i, j]) => { const p = P[i].p, q = P[j].p; if (p && q && (P[i].q[2] + P[j].q[2]) < .8) { x.moveTo(p[0], p[1]); x.lineTo(q[0], q[1]); } }); x.stroke(); x.restore();
};

const L = {};
// ---------- sterren die op je af vliegen ----------
L.stars = (o = {}) => { const k = o.k || 1, st = Array.from({ length: o.n || 150 }, () => ({ x: rr(-3, 3), y: rr(-3, 3), z: rr(.3, 7) }));
  return e => { const x = e.x, sp = e.v * e.dt * k * 1.3; x.lineCap = 'round'; for (const s of st) { s.z += sp; if (s.z > 7) { s.z = .3; s.x = rr(-3, 3); s.y = rr(-3, 3); } const p = e.pr(s.x, s.y, s.z), q = e.pr(s.x, s.y, Math.max(.07, s.z - sp * (o.len || 5) - .015)); if (!p || !q) continue; x.strokeStyle = A(o.alt ? e.c2 : e.c1, cl(1.15 - s.z / 7) * e.a * .9); x.lineWidth = cl(p[2] * .0014, .5, 3.2); x.beginPath(); x.moveTo(q[0], q[1]); x.lineTo(p[0], p[1]); x.stroke(); } }; };
// ---------- tunnel van ringen (3 t/m 8 hoeken) ----------
L.tunnel = o => { o = { sides: 4, n: 16, gap: .75, rad: 1.15, aspect: 1.6, twist: 0, spin: 0, lw: 1.6, ribs: 0, alt: 0, ...o }; let off = 0;
  return e => { const x = e.x; off = (off + e.v * e.dt * .55) % o.gap; x.lineJoin = 'round';
    for (let i = o.n; i >= 0; i--) { const z = .45 + i * o.gap + off, fade = cl(1 - z / (o.n * o.gap)), pts = [];
      for (let k = 0; k < o.sides; k++) { const an = k / o.sides * TAU + o.twist * z + o.spin * e.t + Math.PI / o.sides; pts.push(e.pr(Math.cos(an) * o.rad * o.aspect, Math.sin(an) * o.rad, z)); }
      x.strokeStyle = A(o.alt && (i + ((e.t * 3) | 0)) % 7 === 0 ? e.c2 : e.c1, fade * e.a * .85); x.lineWidth = o.lw * (.5 + fade); stroke3(e, pts, 1); }
    if (o.ribs && !o.twist) for (let k = 0; k < o.sides; k++) { const an = k / o.sides * TAU + Math.PI / o.sides, X = Math.cos(an) * o.rad * o.aspect, Y = Math.sin(an) * o.rad; x.strokeStyle = A(e.c2, .2 * e.a); x.lineWidth = 1; stroke3(e, [e.pr(X, Y, .45), e.pr(X, Y, o.n * o.gap)]); } }; };
// ---------- raster-vloer en plafond ----------
L.floor = (o = {}) => { o = { h: .75, ceil: 1, cols: 10, dx: .5, rows: 22, gap: .55, ...o }; let off = 0;
  return e => { const x = e.x; off = (off + e.v * e.dt * .55) % o.gap; const ys = o.ceil ? [o.h, -o.h] : [o.h], far = o.rows * o.gap, hw = o.cols * o.dx / 2; x.lineWidth = 1.2;
    for (const y of ys) { for (let i = 0; i < o.rows; i++) { const z = .4 + i * o.gap + off; if (z < .35) continue; x.strokeStyle = A(e.c1, cl(1 - z / far) * e.a * .7); stroke3(e, [e.pr(-hw, y, z), e.pr(hw, y, z)]); }
      x.strokeStyle = A(e.c2, e.a * .28); for (let k = 0; k <= o.cols; k++) { const X = -hw + k * o.dx; stroke3(e, [e.pr(X, y, .35), e.pr(X, y, far)]); } } }; };
// ---------- bergen / zee / rimpels als wireframe-landschap ----------
L.terrain = (o = {}) => { o = { rows: 24, cols: 30, w: 7, gap: .5, amp: 1.1, y: .75, type: 'valley', ...o }; let sc = 0;
  const ht = (X, j, t) => { const u = Math.abs(X) / (o.w / 2); if (o.type === 'ocean') return (Math.sin(X * 1.6 + j * .55 + t * 1.5) * Math.cos(j * .4 - t * .9) * .5 + .5) * .5; if (o.type === 'ripple') return Math.sin(Math.hypot(X, j * o.gap) * 2.2 - t * 2.5) * .35 + .35; return Math.pow(u, 1.5) * (.55 + .45 * Math.sin(X * 1.9 + j * .63) * Math.cos(j * .41 + X)); };
  return e => { const x = e.x; sc -= e.v * e.dt * .55; const j0 = Math.floor(sc / o.gap), fr = sc / o.gap - j0;
    for (let i = o.rows; i >= 0; i--) { const j = j0 + i, z = .5 + (i - fr) * o.gap; if (z < .35) continue; const pts = []; for (let c = 0; c <= o.cols; c++) { const X = (c / o.cols - .5) * o.w; pts.push(e.pr(X, o.y - ht(X, j, e.t) * o.amp, z)); } if (pts.some(p => !p)) continue; const fade = cl(1 - z / (o.rows * o.gap));
      path(x, pts); x.lineTo(pts[pts.length - 1][0], e.H + 4); x.lineTo(pts[0][0], e.H + 4); x.closePath(); x.fillStyle = '#050507'; x.fill();
      x.strokeStyle = A(i % 4 === 0 ? e.c2 : e.c1, fade * e.a * .95); x.lineWidth = 1.3; path(x, pts); x.stroke(); } }; };
// ---------- retro-zon ----------
L.sun = (o = {}) => { o = { r: .5, y: -.12, ...o }; return e => { const x = e.x, r = e.f * o.r, cy = e.cy + e.f * o.y; x.save(); const h = x.createRadialGradient(e.cx, cy, r * .6, e.cx, cy, r * 1.9); h.addColorStop(0, A(e.c1, .35 * e.a)); h.addColorStop(1, A(e.c1, 0)); x.fillStyle = h; x.fillRect(0, 0, e.W, e.H);
  const g = x.createLinearGradient(0, cy - r, 0, cy + r); g.addColorStop(0, A(e.c2, .95 * e.a)); g.addColorStop(1, A(e.c1, .95 * e.a)); x.fillStyle = g; x.beginPath(); x.arc(e.cx, cy, r, 0, TAU); x.fill();
  x.fillStyle = '#050507'; for (let k = 0; k < 7; k++) { const sh = mod(e.t * .06, .13), yy = cy + r * (.02 + k * .13 + sh); x.fillRect(e.cx - r, yy, r * 2, r * (.01 + k * .012)); } x.restore(); }; };
// ---------- draaiende draadmodellen ----------
L.poly = o => { o = { shape: 'cube', size: .5, z: 3, spin: 1, count: 1, orbit: 0, vtx: 1, bob: 0, ...o }; const G = GEO[o.shape];
  return e => { const x = e.x; for (let c = 0; c < o.count; c++) { const ph = c / o.count * TAU, ox = o.orbit ? Math.cos(ph + e.t * .6) * o.orbit : 0, oz = o.orbit ? Math.sin(ph + e.t * .6) * o.orbit * .6 : 0, ay = e.t * o.spin + c, ax = e.t * o.spin * .7 + c * .5, oy = Math.sin(e.t * 1.3 + c) * o.bob;
    if (o.shape === 'football') { ball(e, ox, oy, o.z + oz, o.size, ay, ax, e.a); continue; }
    const P = G.v.map(v => { const q = rot(v, ay, ax); return e.pr(q[0] * o.size + ox, q[1] * o.size + oy, q[2] * o.size + o.z + oz); });
    x.strokeStyle = A(c % 2 ? e.c2 : e.c1, e.a * .9); x.lineWidth = 1.6; x.beginPath(); G.e.forEach(([i, j]) => { if (P[i] && P[j]) { x.moveTo(P[i][0], P[i][1]); x.lineTo(P[j][0], P[j][1]); } }); x.stroke();
    if (o.vtx) { x.fillStyle = A('#ffffff', e.a); P.forEach(p => { if (p) { x.beginPath(); x.arc(p[0], p[1], 2.4, 0, TAU); x.fill(); } }); } } }; };
L.torus = (o = {}) => { o = { R: .6, r: .22, z: 3, spin: 1, nu: 28, nv: 12, ...o };
  return e => { const x = e.x, ay = e.t * o.spin, ax = e.t * o.spin * .6 + .6, pt = (u, v) => { const q = rot([(o.R + o.r * Math.cos(v)) * Math.cos(u), (o.R + o.r * Math.cos(v)) * Math.sin(u), o.r * Math.sin(v)], ay, ax); return e.pr(q[0], q[1], q[2] + o.z); }; x.lineWidth = 1;
    x.strokeStyle = A(e.c1, e.a * .75); for (let i = 0; i < o.nu; i++) { const pts = []; for (let j = 0; j <= o.nv; j++) pts.push(pt(i / o.nu * TAU, j / o.nv * TAU)); stroke3(e, pts); }
    x.strokeStyle = A(e.c2, e.a * .5); for (let j = 0; j < o.nv; j++) { const pts = []; for (let i = 0; i <= o.nu; i++) pts.push(pt(i / o.nu * TAU, j / o.nv * TAU)); stroke3(e, pts); } }; };
L.sphere = (o = {}) => { o = { r: .8, z: 3.2, spin: .5, nlat: 8, nlon: 14, dots: 0, ...o };
  return e => { const x = e.x, ay = e.t * o.spin, pt = (la, lo) => { const q = rot([Math.cos(la) * Math.cos(lo) * o.r, Math.sin(la) * o.r, Math.cos(la) * Math.sin(lo) * o.r], ay, .35); return e.pr(q[0], q[1], q[2] + o.z); }; x.lineWidth = 1; x.strokeStyle = A(e.c1, e.a * (o.dots ? .25 : .6));
    for (let i = 1; i < o.nlat; i++) { const la = -Math.PI / 2 + i / o.nlat * Math.PI, pts = []; for (let k = 0; k <= 40; k++) pts.push(pt(la, k / 40 * TAU)); stroke3(e, pts); }
    for (let k = 0; k < o.nlon; k++) { const lo = k / o.nlon * TAU, pts = []; for (let i = 0; i <= 20; i++) pts.push(pt(-Math.PI / 2 + i / 20 * Math.PI, lo)); stroke3(e, pts); }
    if (o.dots) { x.globalCompositeOperation = 'lighter'; for (let i = 1; i < o.nlat; i++) for (let k = 0; k < o.nlon; k++) { const p = pt(-Math.PI / 2 + i / o.nlat * Math.PI, k / o.nlon * TAU); if (!p) continue; const tw = Math.sin(e.t * 4 + i * 3.1 + k * 1.7) * .5 + .5; x.fillStyle = A(tw > .6 ? '#ffffff' : e.c2, e.a * (.3 + tw * .7)); x.beginPath(); x.arc(p[0], p[1], 2 + tw * 3, 0, TAU); x.fill(); } } }; };
// ---------- DNA-helix ----------
L.helix = (o = {}) => { o = { n: 46, axis: 'y', r: .55, len: 3, z: 3, spin: 1.3, turns: 3.2, ...o };
  return e => { const x = e.x, ph = e.t * o.spin, P = (i, s) => { const u = i / o.n, an = u * o.turns * TAU + ph + s * Math.PI; if (o.axis === 'y') return e.pr(Math.cos(an) * o.r, (u - .5) * o.len, o.z + Math.sin(an) * o.r); return e.pr(Math.cos(an) * o.r, Math.sin(an) * o.r, .6 + u * 6.5); };
    for (let s = 0; s < 2; s++) { const pts = []; for (let i = 0; i <= o.n; i++) pts.push(P(i, s)); x.strokeStyle = A(s ? e.c2 : e.c1, e.a * .95); x.lineWidth = 2.6; stroke3(e, pts); }
    x.lineWidth = 1.2; for (let i = 0; i <= o.n; i += 2) { const a = P(i, 0), b = P(i, 1); x.strokeStyle = A('#ffffff', e.a * (o.axis === 'y' ? .35 : cl(1 - i / o.n) * .5)); stroke3(e, [a, b]); } }; };
// ---------- sterrenstelsel & zwart gat ----------
L.galaxy = (o = {}) => { o = { n: 380, arms: 3, twist: 3.2, z: 3.4, size: 1.3, tilt: 1.1, spin: .25, ...o };
  const ps = Array.from({ length: o.n }, (_, i) => { const r = Math.pow(R(), .7); return { r, a: (i % o.arms) / o.arms * TAU + r * o.twist + rr(-.28, .28) * (1 - r * .4), y: rr(-.05, .05) * (1 - r), s: rr(.8, 2.6), w: R() < .15 }; });
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; const c = e.pr(0, 0, o.z); if (c) { const g = x.createRadialGradient(c[0], c[1], 0, c[0], c[1], e.f * .5 / o.z); g.addColorStop(0, A('#ffffff', .5 * e.a)); g.addColorStop(.3, A(e.c2, .25 * e.a)); g.addColorStop(1, A(e.c2, 0)); x.fillStyle = g; x.fillRect(0, 0, e.W, e.H); }
    for (const p of ps) { const an = p.a + e.t * o.spin * (1.3 - p.r * .7), q = rot([Math.cos(an) * p.r * o.size, p.y, Math.sin(an) * p.r * o.size], 0, o.tilt, .25), s = e.pr(q[0], q[1], q[2] + o.z); if (!s) continue; x.fillStyle = A(p.w ? '#ffffff' : p.r < .35 ? e.c2 : e.c1, e.a * (.35 + .5 * (1 - p.r))); x.fillRect(s[0], s[1], p.s, p.s); } }; };
L.blackhole = (o = {}) => { o = { n: 260, z: 3.2, ...o }; const ps = Array.from({ length: o.n }, () => ({ r: rr(.12, 1.5), a: rr(0, TAU), w: rr(.8, 1.2) }));
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; const pj = (r, a) => { const q = rot([Math.cos(a) * r, 0, Math.sin(a) * r], 0, .95, .2); return e.pr(q[0], q[1], q[2] + o.z); };
    for (const p of ps) { p.r -= e.dt * (.05 + .14 / (p.r + .1)) * p.w; p.a += e.dt * (.5 / (p.r + .12)) * p.w; if (p.r < .1) { p.r = rr(.9, 1.6); p.a = rr(0, TAU); } const s = pj(p.r, p.a); if (!s) continue; x.fillStyle = A(p.r < .4 ? '#ffffff' : p.r < .8 ? e.c2 : e.c1, e.a * cl(1.1 - p.r * .6)); const z = cl(2.4 / (p.r + .3), 1, 7); x.fillRect(s[0], s[1], z * .5 + 1, z * .5 + 1); }
    const c = e.pr(0, 0, o.z); if (c) { const rr_ = c[2] * .2; x.globalCompositeOperation = 'source-over'; const g = x.createRadialGradient(c[0], c[1], rr_ * .8, c[0], c[1], rr_ * 2.4); g.addColorStop(0, A(e.c2, .5 * e.a)); g.addColorStop(1, A(e.c2, 0)); x.fillStyle = g; x.beginPath(); x.arc(c[0], c[1], rr_ * 2.4, 0, TAU); x.fill(); x.fillStyle = '#000'; x.beginPath(); x.arc(c[0], c[1], rr_, 0, TAU); x.fill(); x.strokeStyle = A('#ffffff', .8 * e.a); x.lineWidth = 2; x.beginPath(); x.arc(c[0], c[1], rr_ * 1.03, 0, TAU); x.stroke(); } }; };
// ---------- wervelende stroom deeltjes ----------
L.vortex = (o = {}) => { o = { n: 170, tw: 1.6, r0: .25, r1: 1.3, ...o }; const mk = far => ({ a: rr(0, TAU), r: rr(o.r0, o.r1), z: far ? .4 : rr(.4, 7), w: rr(.7, 1.3) }), ps = Array.from({ length: o.n }, () => mk());
  return e => { const x = e.x, sp = e.v * e.dt * 1.1; x.lineCap = 'round'; for (let i = 0; i < ps.length; i++) { const p = ps[i]; p.z += sp * p.w; p.a += e.dt * o.tw * p.w / (p.r + .3); if (p.z > 7) { ps[i] = mk(1); continue; }
    const P1 = e.pr(Math.cos(p.a) * p.r, Math.sin(p.a) * p.r, p.z), P0 = e.pr(Math.cos(p.a - .22 * o.tw) * p.r, Math.sin(p.a - .22 * o.tw) * p.r, Math.max(.07, p.z - sp * 6 - .04)); if (!P0 || !P1) continue; x.strokeStyle = A(p.w > 1 ? e.c1 : e.c2, cl(1 - p.z / 7) * e.a); x.lineWidth = cl(P1[2] * .0013, .5, 3); x.beginPath(); x.moveTo(P0[0], P0[1]); x.lineTo(P1[0], P1[1]); x.stroke(); } }; };
// ---------- lasers & stadionlampen & cameraflitsen ----------
L.lasers = (o = {}) => { o = { n: 7, z: 5, floor: 0, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; for (let i = 0; i < o.n; i++) { const side = i % 2 ? 1 : -1, ph = i * 1.7, org = e.pr(side * 2.4, o.floor ? 1.1 : -1.1, o.z), tgt = e.pr(Math.sin(e.t * .9 + ph) * 3.5, Math.cos(e.t * 1.3 + ph * .7) * 1.4, 1.2); if (!org || !tgt) continue;
    const ex = org[0] + (tgt[0] - org[0]) * 1.9, ey = org[1] + (tgt[1] - org[1]) * 1.9, col = i % 2 ? e.c1 : e.c2; x.strokeStyle = A(col, .14 * e.a); x.lineWidth = 9; x.beginPath(); x.moveTo(org[0], org[1]); x.lineTo(ex, ey); x.stroke(); x.strokeStyle = A(mix(col, '#ffffff', .6), .85 * e.a); x.lineWidth = 1.8; x.stroke(); x.fillStyle = A('#ffffff', e.a); x.beginPath(); x.arc(org[0], org[1], 4, 0, TAU); x.fill(); } }; };
L.lights = (o = {}) => { o = { rows: 2, cols: 6, z: 8, w: 5, y: [-1.4, -.9], ...o };
  return e => { const x = e.x, zz = o.z * (.7 + .5 * cl(e.t / 16)); x.globalCompositeOperation = 'lighter'; for (let r = 0; r < o.rows; r++) for (let c = 0; c < o.cols; c++) { const X = (o.cols > 1 ? c / (o.cols - 1) - .5 : 0) * o.w, p = e.pr(X, o.y[r % o.y.length], zz + r * .4); if (!p) continue; const fl = .65 + .35 * Math.sin(e.t * 2.7 + c * 1.3 + r * 2.1), rad = e.H * .1 * (.6 + .4 * fl) * (8 / zz) * .7 * e.a, g = x.createRadialGradient(p[0], p[1], 0, p[0], p[1], rad);
    g.addColorStop(0, A('#ffffff', fl * e.a)); g.addColorStop(.25, A(e.c2, .55 * fl * e.a)); g.addColorStop(1, A(e.c1, 0)); x.fillStyle = g; x.fillRect(p[0] - rad, p[1] - rad, rad * 2, rad * 2); x.strokeStyle = A('#ffffff', .5 * fl * e.a); x.lineWidth = 1; x.beginPath(); x.moveTo(p[0] - rad * 1.2, p[1]); x.lineTo(p[0] + rad * 1.2, p[1]); x.stroke(); } }; };
L.flashes = (o = {}) => { o = { rate: 9, ...o }; const fl = [];
  return e => { const x = e.x; if (R() < o.rate * e.dt * e.a) fl.push({ x: rr(.04, .96) * e.W, y: rr(.12, .88) * e.H, l: 1, s: rr(.5, 1.3) }); x.globalCompositeOperation = 'lighter';
    for (let i = fl.length - 1; i >= 0; i--) { const f = fl[i]; f.l -= e.dt * 4.5; if (f.l <= 0) { fl.splice(i, 1); continue; } const r = e.H * .07 * f.s * (.4 + f.l), g = x.createRadialGradient(f.x, f.y, 0, f.x, f.y, r); g.addColorStop(0, A('#ffffff', f.l)); g.addColorStop(.25, A(e.c2, f.l * .5)); g.addColorStop(1, A(e.c2, 0)); x.fillStyle = g; x.fillRect(f.x - r, f.y - r, r * 2, r * 2);
      x.strokeStyle = A('#ffffff', f.l * .7); x.lineWidth = 1.2; x.beginPath(); x.moveTo(f.x - r * 1.3, f.y); x.lineTo(f.x + r * 1.3, f.y); x.moveTo(f.x, f.y - r * 1.3); x.lineTo(f.x, f.y + r * 1.3); x.stroke(); } }; };
// ---------- vuurwerk, bliksem, weer ----------
L.fireworks = (o = {}) => { o = { rate: .9, ...o }; const rk = [], ps = [];
  return e => { const x = e.x; if (R() < o.rate * e.dt) rk.push({ X: rr(-2, 2), Y: 1.3, Z: rr(3, 5.5), vy: -rr(2.4, 3.2), c: (R() * 3) | 0 }); x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; const cols = [e.c1, e.c2, '#ffffff'];
    for (let i = rk.length - 1; i >= 0; i--) { const r = rk[i]; r.vy += 2.1 * e.dt; r.Y += r.vy * e.dt; const p = e.pr(r.X, r.Y, r.Z), q = e.pr(r.X, r.Y + .18, r.Z); if (p && q) { x.strokeStyle = A('#ffffff', .9 * e.a); x.lineWidth = 2; stroke3(e, [q, p]); }
      if (r.vy > -.15) { for (let k = 0; k < 90; k++) { const u = rr(-1, 1), a = rr(0, TAU), s = Math.sqrt(1 - u * u) * rr(.35, 1.1), sp = rr(.5, 1.3); ps.push({ X: r.X, Y: r.Y, Z: r.Z, vx: Math.cos(a) * s * sp, vy: u * sp, vz: Math.sin(a) * s * sp, l: 1, c: cols[(r.c + (k % 5 === 0 ? 1 : 0)) % 3] }); } rk.splice(i, 1); } }
    for (let i = ps.length - 1; i >= 0; i--) { const p = ps[i]; p.l -= e.dt * .7; if (p.l <= 0) { ps.splice(i, 1); continue; } const a = e.pr(p.X, p.Y, p.Z); p.X += p.vx * e.dt; p.Y += p.vy * e.dt; p.Z += p.vz * e.dt; p.vy += .6 * e.dt; p.vx *= .985; p.vz *= .985; const b = e.pr(p.X, p.Y, p.Z); if (!a || !b) continue; x.strokeStyle = A(p.c, p.l * e.a); x.lineWidth = cl(b[2] * .003 * p.l + .6, .6, 3); x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke(); } }; };
L.lightning = (o = {}) => { o = { rate: .45, ...o }; let bolt = null, fl = 0;
  const gen = () => { const X0 = rr(-2, 2), X1 = X0 + rr(-1, 1), Z = rr(2.5, 5), pts = [], n = 12; for (let i = 0; i <= n; i++) { const u = i / n; pts.push([X0 + (X1 - X0) * u + (i && i < n ? rr(-.22, .22) : 0), -1.8 + u * 3.2, Z]); } const k = 3 + ((R() * 6) | 0), br = [pts[k]], sd = R() < .5 ? -1 : 1; for (let i = 1; i <= 5; i++) br.push([br[i - 1][0] + sd * rr(.05, .2), br[i - 1][1] + rr(.1, .22), Z]); bolt = { pts, br, l: 1 }; fl = 1; };
  return e => { const x = e.x; if (e.a > .2 && R() < o.rate * e.dt) gen(); if (bolt) { bolt.l -= e.dt * 2.8; if (bolt.l <= 0) bolt = null; else { x.globalCompositeOperation = 'lighter'; x.lineJoin = 'round'; [bolt.pts, bolt.br].forEach((pts, k) => { const P = pts.map(p => e.pr(p[0], p[1], p[2])); x.strokeStyle = A(e.c1, .28 * bolt.l * e.a); x.lineWidth = k ? 5 : 9; stroke3(e, P); x.strokeStyle = A('#ffffff', bolt.l); x.lineWidth = k ? 1.4 : 2.6; stroke3(e, P); }); } }
    if (fl > .01) { x.globalCompositeOperation = 'lighter'; x.fillStyle = A(e.c2, fl * .2); x.fillRect(0, 0, e.W, e.H); fl -= e.dt * 4.5; } }; };
L.rain = (o = {}) => { o = { kind: 'rain', n: 150, ...o }; const K = { rain: { vy: 5, vx: -.6, len: .5, col: 0 }, snow: { vy: .6, vx: .1, len: 0, col: 2 }, embers: { vy: -.9, vx: .15, len: .12, col: 1 }, bubbles: { vy: -.7, vx: 0, len: 0, col: 0 }, dust: { vy: .05, vx: -.8, len: 0, col: 1 } }[o.kind];
  const ps = Array.from({ length: o.n }, () => ({ x: rr(-3, 3), y: rr(-2, 2), z: rr(.5, 6), w: rr(.7, 1.3), ph: rr(0, TAU) }));
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; const c = [e.c1, e.c2, '#ffffff'][K.col]; for (const p of ps) { p.y += K.vy * p.w * e.dt; p.x += (K.vx + (o.kind === 'rain' ? 0 : Math.sin(e.t + p.ph) * .25)) * e.dt * p.w; p.z += e.v * e.dt * .3; if (p.y > 2) p.y = -2; if (p.y < -2) p.y = 2; if (p.z > 6) p.z = .5; if (Math.abs(p.x) > 3) p.x = -Math.sign(p.x) * 3; const s = e.pr(p.x, p.y, p.z); if (!s) continue; const al = cl(1 - p.z / 6) * e.a;
    if (K.len) { const q = e.pr(p.x - K.vx * K.len * .3, p.y - Math.sign(K.vy) * K.len, p.z); x.strokeStyle = A(c, al * .8); x.lineWidth = cl(s[2] * .0012, .5, 2.5); stroke3(e, [q, s]); }
    else if (o.kind === 'bubbles') { x.strokeStyle = A(c, al * .8); x.lineWidth = 1; x.beginPath(); x.arc(s[0], s[1], cl(s[2] * .012 * p.w, 2, 26), 0, TAU); x.stroke(); }
    else { x.fillStyle = A(c, al); x.beginPath(); x.arc(s[0], s[1], cl(s[2] * .006 * p.w, .8, 7), 0, TAU); x.fill(); } } }; };
L.glyphs = (o = {}) => { o = { n: 40, chars: '0123456789ABCDEFGHJKLMNPRSTUVWXYZ★', ...o }; const mk = () => ({ x: rr(-3, 3), z: rr(.8, 5), y: rr(-2, 2), v: rr(1, 2.4), len: 9 + ((R() * 8) | 0) }), cols = Array.from({ length: o.n }, mk);
  return e => { const x = e.x; x.textAlign = 'center'; const N = o.chars.length; for (const c of cols) { c.y += c.v * e.dt; if (c.y - c.len * .17 > 2) Object.assign(c, mk(), { y: -2 }); for (let i = 0; i < c.len; i++) { const s = e.pr(c.x, c.y - i * .17, c.z); if (!s) continue; x.font = `700 ${Math.max(6, s[2] * .06) | 0}px monospace`; x.fillStyle = A(i ? e.c1 : '#ffffff', cl(1 - i / c.len) * cl(1 - c.z / 6) * e.a); x.fillText(o.chars[(Math.floor(c.x * 91 + 300) + i * 7 + Math.floor(e.t * (i ? 3 : 8))) % N], s[0], s[1]); } } }; };
// ---------- schokgolven, confetti, noorderlicht ----------
L.shock = (o = {}) => { o = { rate: .8, z: 3.2, y: .7, ...o }; const rs = []; let tm = 9;
  return e => { const x = e.x; tm += e.dt; if (tm > 1 / o.rate) { tm = 0; rs.push(0); } for (let i = rs.length - 1; i >= 0; i--) { rs[i] += e.dt * 1.1; if (rs[i] > 3.2) { rs.splice(i, 1); continue; } const r = rs[i], pts = []; for (let k = 0; k <= 48; k++) { const an = k / 48 * TAU; pts.push(e.pr(Math.cos(an) * r, o.y, o.z + Math.sin(an) * r)); } const f = cl(1 - r / 3.2); x.strokeStyle = A(e.c1, f * e.a); x.lineWidth = 3 * f + .5; stroke3(e, pts); } }; };
L.confetti = (o = {}) => { o = { n: 110, ...o }; const mk = far => ({ x: rr(-2.5, 2.5), y: far ? -2 : rr(-2, 2), z: rr(.8, 5), a: rr(0, TAU), b: rr(0, TAU), va: rr(-5, 5), vb: rr(-5, 5), c: (R() * 4) | 0, s: rr(.03, .07), vy: rr(.4, 1) }), ps = Array.from({ length: o.n }, () => mk());
  return e => { const x = e.x; for (let i = 0; i < ps.length; i++) { const p = ps[i]; p.y += p.vy * e.dt; p.a += p.va * e.dt; p.b += p.vb * e.dt; p.x += Math.sin(p.b) * .2 * e.dt; if (p.y > 2) { ps[i] = mk(1); continue; } const pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => { const q = rot([u * p.s, v * p.s, 0], p.a, p.b); return e.pr(p.x + q[0], p.y + q[1], p.z + q[2]); }); if (pts.some(q => !q)) continue;
    x.fillStyle = A([e.c1, e.c2, '#ffffff', mix(e.c1, '#ffffff', .5)][p.c], e.a * (.5 + .5 * Math.abs(Math.cos(p.a)))); path(x, pts); x.fill(); } }; };
L.aurora = (o = {}) => { o = { bands: 4, y: -.35, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; for (let b = 0; b < o.bands; b++) { const N = 36, top = [], bot = []; for (let i = 0; i <= N; i++) { const u = i / N, X = (u - .5) * 6, yy = o.y + Math.sin(u * 5 + e.t * .7 + b * 1.3) * .22 + Math.sin(u * 11 - e.t * 1.1 + b) * .06 + b * .06, hh = .5 + .25 * Math.sin(u * 3 + e.t * .5 + b), z = 2.4 + b * .5; top.push(e.pr(X, yy - hh, z)); bot.push(e.pr(X, yy + .04, z)); }
    if (top.some(p => !p) || bot.some(p => !p)) continue; const col = b % 2 ? e.c1 : e.c2, g = x.createLinearGradient(0, e.cy - e.f * .6, 0, e.cy + e.f * .1); g.addColorStop(0, A(col, 0)); g.addColorStop(1, A(col, .4 * e.a)); x.fillStyle = g; path(x, top.concat(bot.slice().reverse())); x.closePath(); x.fill(); } }; };
// ---------- vliegende kubussen, poorten, kaarten ----------
L.cubes = (o = {}) => { o = { n: 22, size: .13, ...o }; const mk = far => ({ x: rr(-2.2, 2.2), y: rr(-1.4, 1.4), z: far ? .6 : rr(.8, 7), a: rr(0, TAU), b: rr(0, TAU), va: rr(-1.5, 1.5), vb: rr(-1.5, 1.5), s: o.size * rr(.6, 1.6) }), cs = Array.from({ length: o.n }, () => mk());
  return e => { const x = e.x; x.lineWidth = 1.3; for (let i = 0; i < cs.length; i++) { const c = cs[i]; c.z += e.v * e.dt * .7; c.a += c.va * e.dt; c.b += c.vb * e.dt; if (c.z > 7) { cs[i] = mk(1); continue; } const P = GEO.cube.v.map(v => { const q = rot(v, c.a, c.b); return e.pr(c.x + q[0] * c.s, c.y + q[1] * c.s, c.z + q[2] * c.s); }); x.strokeStyle = A(i % 3 ? e.c1 : e.c2, cl(1 - c.z / 7) * e.a); x.beginPath(); GEO.cube.e.forEach(([p, q]) => { if (P[p] && P[q]) { x.moveTo(P[p][0], P[p][1]); x.lineTo(P[q][0], P[q][1]); } }); x.stroke(); } }; };
L.gates = (o = {}) => { o = { n: 7, gap: 1, rad: .95, shape: 'circle', dash: [14, 10], ...o }; let off = 0;
  return e => { const x = e.x; off = (off + e.v * e.dt * .6) % o.gap; for (let i = o.n; i >= 0; i--) { const z = .5 + i * o.gap + off, fade = cl(1 - z / (o.n * o.gap)), r = o.rad * e.f / z; x.strokeStyle = A(i % 2 ? e.c2 : e.c1, fade * e.a); x.lineWidth = cl(r * .03, 1, 14); x.setLineDash(o.dash.map(d => d * (.4 + fade))); x.lineDashOffset = -e.t * 60 * (i % 2 ? 1 : -1); x.beginPath(); if (o.shape === 'circle') x.arc(e.cx, e.cy, r, 0, TAU); else x.rect(e.cx - r, e.cy - r * .65, r * 2, r * 1.3); x.stroke(); } x.setLineDash([]); }; };
L.ghostcards = (o = {}) => { o = { n: 9, ...o }; const mk = far => ({ x: rr(-1.8, 1.8), y: rr(-1.1, 1.1), z: far ? .7 : rr(1, 7), a: rr(0, TAU), va: rr(-1.4, 1.4), b: rr(-.5, .5) }), cs = Array.from({ length: o.n }, () => mk());
  return e => { const x = e.x; x.lineJoin = 'round'; for (let i = 0; i < cs.length; i++) { const c = cs[i]; c.z += e.v * e.dt * .55; c.a += c.va * e.dt; if (c.z > 7) { cs[i] = mk(1); continue; } const pts = [[-.23, -.33], [.23, -.33], [.23, .33], [-.23, .33]].map(([u, v]) => { const q = rot([u * .8, v * .8, 0], c.a, c.b); return e.pr(c.x + q[0], c.y + q[1], c.z + q[2]); }); if (pts.some(p => !p)) continue;
    const fade = cl(1 - c.z / 7) * e.a, col = [e.c1, e.c2, '#ffffff'][i % 3], lp = (u, v) => [pts[0][0] + (pts[1][0] - pts[0][0]) * u + (pts[3][0] - pts[0][0]) * v, pts[0][1] + (pts[1][1] - pts[0][1]) * u + (pts[3][1] - pts[0][1]) * v];
    path(x, pts); x.closePath(); x.fillStyle = A(col, fade * .13); x.fill(); x.strokeStyle = A(col, fade); x.lineWidth = 1.6; x.stroke(); x.lineWidth = 3; path(x, [lp(.15, .12), lp(.5, .12)]); x.stroke(); x.lineWidth = 1.4; path(x, [lp(.15, .72), lp(.8, .72)]); x.stroke(); path(x, [lp(.15, .8), lp(.6, .8)]); x.stroke(); } }; };
// ---------- voetbalveld, doelen, bal ----------
L.pitch = (o = {}) => { o = { s: .028, z: 3.6, y: .55, tilt: .5, spin: .15, ...o }; const segs = [], circ = (cu, cv, r, a0 = 0, a1 = TAU, n = 36) => Array.from({ length: n + 1 }, (_, i) => [cu + Math.cos(a0 + (a1 - a0) * i / n) * r, cv + Math.sin(a0 + (a1 - a0) * i / n) * r]);
  segs.push([[-52.5, -34], [52.5, -34], [52.5, 34], [-52.5, 34], [-52.5, -34]], [[0, -34], [0, 34]], circ(0, 0, 9.15)); [-1, 1].forEach(sd => { const g = sd * 52.5; segs.push([[g, -20.16], [g - sd * 16.5, -20.16], [g - sd * 16.5, 20.16], [g, 20.16]], [[g, -9.16], [g - sd * 5.5, -9.16], [g - sd * 5.5, 9.16], [g, 9.16]], circ(g - sd * 11, 0, .6, 0, TAU, 8), circ(g - sd * 11, 0, 9.15, sd > 0 ? Math.PI - .93 : -.93, sd > 0 ? Math.PI + .93 : .93, 16)); });
  return e => { const x = e.x, yaw = e.t * o.spin, pj = (u, v) => { const q = rot([u * o.s, 0, v * o.s], yaw, o.tilt); return e.pr(q[0], q[1] + o.y, q[2] + o.z); };
    for (let k = 0; k < 10; k += 2) { const u0 = -52.5 + k * 10.5, pts = [pj(u0, -34), pj(u0 + 10.5, -34), pj(u0 + 10.5, 34), pj(u0, 34)]; if (pts.every(p => p)) { path(x, pts); x.closePath(); x.fillStyle = A(e.c1, .09 * e.a); x.fill(); } }
    x.lineWidth = 2; x.strokeStyle = A(e.c1, .95 * e.a); x.lineJoin = 'round'; segs.forEach(s => stroke3(e, s.map(p => pj(p[0], p[1])))); const c = pj(0, 0); if (c) { x.fillStyle = A('#ffffff', e.a); x.beginPath(); x.arc(c[0], c[1], 3, 0, TAU); x.fill(); } }; };
L.goal = (o = {}) => { o = { n: 6, gap: 1.6, w: 1.1, h: 1.0, d: .7, ...o }; let off = 0;
  return e => { const x = e.x, y0 = .8, yt = y0 - o.h; off = (off + e.v * e.dt * .6) % o.gap; x.lineJoin = 'round'; for (let i = o.n; i >= 0; i--) { const z = .6 + i * o.gap + off, fade = cl(1 - z / (o.n * o.gap)), W = o.w, zb = z + o.d, yb = yt + .15;
    x.strokeStyle = A(e.c2, fade * e.a * .35); x.lineWidth = 1; for (let k = -4; k <= 4; k++) stroke3(e, [e.pr(W * k / 4, yb, zb), e.pr(W * k / 4, y0, zb)]); for (let k = 0; k <= 4; k++) { const Y = yb + (y0 - yb) * k / 4; stroke3(e, [e.pr(-W, Y, zb), e.pr(W, Y, zb)]); } [-1, 1].forEach(sd => stroke3(e, [e.pr(sd * W, yt, z), e.pr(sd * W, yb, zb)])); stroke3(e, [e.pr(-W, yt, z), e.pr(-W, yb, zb), e.pr(W, yb, zb), e.pr(W, yt, z)]);
    x.strokeStyle = A('#ffffff', fade * e.a); x.lineWidth = cl(fade * 5 + 1, 1, 6); stroke3(e, [e.pr(-W, y0, z), e.pr(-W, yt, z), e.pr(W, yt, z), e.pr(W, y0, z)]); } }; };
L.ballfly = (o = {}) => { o = { ...o }; const tr = [];
  return e => { const x = e.x, u = (e.t * .33) % 1, z = 6.2 - u * 5.4, X = Math.sin(e.t * .8) * .7 * (1 - u * .5), Y = .52 - Math.abs(Math.sin(u * Math.PI * 4)) * .85 * (1 - u * .3), sh = e.pr(X, .8, z); if (sh) { x.save(); x.globalCompositeOperation = 'lighter'; x.translate(sh[0], sh[1]); x.scale(1, .22); const g = x.createRadialGradient(0, 0, 0, 0, 0, sh[2] * .3); g.addColorStop(0, A(e.c1, .5 * e.a)); g.addColorStop(1, A(e.c1, 0)); x.fillStyle = g; x.beginPath(); x.arc(0, 0, sh[2] * .3, 0, TAU); x.fill(); x.restore(); }
    const c = e.pr(X, Y, z); if (c) { if (u < .02) tr.length = 0; tr.push(c); if (tr.length > 18) tr.shift(); x.save(); x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; for (let i = 1; i < tr.length; i++) { x.strokeStyle = A(e.c1, i / tr.length * .6 * e.a); x.lineWidth = i / tr.length * c[2] * .12; stroke3(e, [tr[i - 1], tr[i]]); } x.restore(); }
    ball(e, X, Y, z, .26, e.t * 3, e.t * 2, e.a); }; };
// ---------- spots, hexagonen, banen ----------
L.cones = (o = {}) => { o = { n: 5, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; for (let i = 0; i < o.n; i++) { const bx = e.W * ((i + .5) / o.n), tx = bx + Math.sin(e.t * .8 + i * 1.9) * e.W * .28, w0 = e.W * .012, w1 = e.W * .1, col = i % 2 ? e.c1 : e.c2, g = x.createLinearGradient(0, 0, 0, e.H); g.addColorStop(0, A(col, .4 * e.a)); g.addColorStop(1, A(col, 0)); x.fillStyle = g; x.beginPath(); x.moveTo(bx - w0, -4); x.lineTo(bx + w0, -4); x.lineTo(tx + w1, e.H); x.lineTo(tx - w1, e.H); x.closePath(); x.fill();
    x.save(); x.translate(tx, e.H * .93); x.scale(1, .2); const r = w1 * 1.6, g2 = x.createRadialGradient(0, 0, 0, 0, 0, r); g2.addColorStop(0, A(col, .55 * e.a)); g2.addColorStop(1, A(col, 0)); x.fillStyle = g2; x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fill(); x.restore(); } }; };
L.hex = (o = {}) => { o = { z: 2.6, size: .26, rings: 5, ...o }; const cells = []; for (let q = -o.rings; q <= o.rings; q++) for (let r = -o.rings; r <= o.rings; r++) { if (Math.abs(q + r) > o.rings) continue; cells.push({ X: Math.sqrt(3) * (q + r / 2), Y: 1.5 * r, d: Math.hypot(q, r) }); }
  return e => { const x = e.x, yaw = Math.sin(e.t * .35) * .55, pit = Math.cos(e.t * .27) * .25; x.lineWidth = 1.2; for (const c of cells) { const pulse = Math.sin(c.d * .9 - e.t * 2.4) * .5 + .5, pts = []; for (let k = 0; k < 6; k++) { const an = k / 6 * TAU + Math.PI / 6, q = rot([(c.X + Math.cos(an) * .96) * o.size, (c.Y + Math.sin(an) * .96) * o.size, 0], yaw, pit); pts.push(e.pr(q[0], q[1], q[2] + o.z)); } if (pts.some(p => !p)) continue; x.strokeStyle = A(pulse > .8 ? '#ffffff' : e.c1, e.a * (.25 + pulse * .6)); stroke3(e, pts, 1); if (pulse > .75) { x.fillStyle = A(e.c2, (pulse - .75) * e.a); x.fill(); } } }; };
L.orbiters = (o = {}) => { o = { n: 6, z: 3, trail: 14, ...o }; const os = Array.from({ length: o.n }, (_, i) => ({ r: rr(.6, 1.5), sp: rr(.8, 2) * (i % 2 ? 1 : -1), ph: rr(0, TAU), tx: rr(0, 3), tz: rr(0, 3), tr: [] }));
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; for (const b of os) { const an = e.t * b.sp + b.ph, q = rot([Math.cos(an) * b.r, Math.sin(an * 1.3) * b.r * .35, Math.sin(an) * b.r], b.tx, b.tz), s = e.pr(q[0], q[1], q[2] + o.z); if (!s) continue; b.tr.push(s); if (b.tr.length > o.trail) b.tr.shift();
    for (let i = 1; i < b.tr.length; i++) { x.strokeStyle = A(e.c1, i / b.tr.length * e.a * .8); x.lineWidth = i / b.tr.length * 4; stroke3(e, [b.tr[i - 1], b.tr[i]]); } const r = cl(s[2] * .018, 3, 18), g = x.createRadialGradient(s[0], s[1], 0, s[0], s[1], r * 2.5); g.addColorStop(0, A('#ffffff', e.a)); g.addColorStop(.3, A(e.c2, e.a * .7)); g.addColorStop(1, A(e.c2, 0)); x.fillStyle = g; x.beginPath(); x.arc(s[0], s[1], r * 2.5, 0, TAU); x.fill(); } }; };
L.lissa = (o = {}) => { o = { a: 3, b: 2, c: 5, n: 160, z: 3, size: 1.1, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; let prev = null; for (let i = 0; i < o.n; i++) { const u = e.t * 1.3 - i * .035, q = rot([Math.sin(o.a * u + 1) * o.size, Math.sin(o.b * u) * o.size * .7, Math.cos(o.c * u) * .6], e.t * .3, .4), s = e.pr(q[0], q[1], q[2] + o.z); if (prev && s) { const f = 1 - i / o.n; x.strokeStyle = A(i % 12 < 6 ? e.c1 : e.c2, f * e.a); x.lineWidth = 1 + f * 4; stroke3(e, [prev, s]); } prev = s; } }; };
L.knot = (o = {}) => { o = { p: 2, q: 3, z: 3.2, size: .75, n: 180, ...o };
  return e => { const x = e.x, ay = e.t * .6, ax = e.t * .4; x.lineWidth = 2.2; let prev = null; for (let i = 0; i <= o.n; i++) { const u = i / o.n * TAU, r = Math.cos(o.q * u) + 2, q = rot([r * Math.cos(o.p * u) * o.size * .4, r * Math.sin(o.p * u) * o.size * .4, -Math.sin(o.q * u) * o.size * .4], ay, ax), s = e.pr(q[0], q[1], q[2] + o.z); if (prev && s) { x.strokeStyle = A(i % 8 < 4 ? e.c1 : e.c2, e.a * (.4 + .6 * (1 - cl((q[2] + 1) / 2)))); stroke3(e, [prev, s]); } prev = s; } }; };
L.radar = (o = {}) => { o = { y: .7, z: 3, ...o }; const bl = Array.from({ length: 7 }, () => ({ a: rr(0, TAU), r: rr(.3, 1), l: 0 }));
  return e => { const x = e.x, P = (r, an) => e.pr(Math.cos(an) * r * 1.8, o.y, o.z + Math.sin(an) * r * 1.8); x.lineWidth = 1.2; for (let k = 1; k <= 4; k++) { x.strokeStyle = A(e.c1, e.a * .45); const pts = []; for (let i = 0; i <= 56; i++) pts.push(P(k / 4, i / 56 * TAU)); stroke3(e, pts); } for (let k = 0; k < 8; k++) { x.strokeStyle = A(e.c1, e.a * .2); stroke3(e, [P(0, 0), P(1, k / 8 * TAU)]); }
    const sw = e.t * 1.8; for (let i = 0; i < 26; i++) { x.strokeStyle = A(e.c2, e.a * (1 - i / 26) * .8); stroke3(e, [P(0, 0), P(1, sw - i * .03)]); } x.globalCompositeOperation = 'lighter';
    for (const b of bl) { if (mod(sw - b.a, TAU) < .14) b.l = 1; b.l = Math.max(0, b.l - e.dt * .7); const p = P(b.r, b.a); if (p && b.l > 0) { x.fillStyle = A('#ffffff', b.l * e.a); x.beginPath(); x.arc(p[0], p[1], 3 + b.l * 5, 0, TAU); x.fill(); } } }; };
L.eq = (o = {}) => { o = { cols: 15, rows: 9, y: .75, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; for (let j = o.rows - 1; j >= 0; j--) for (let i = 0; i < o.cols; i++) { const X = (i - (o.cols - 1) / 2) * .34, z = 1.1 + j * .55, h = (.25 + .75 * Math.abs(Math.sin(e.t * 2.3 + i * .9 + j * .6) * Math.cos(e.t * 1.1 + i * .3 - j))) * 1.1 * e.a, p0 = e.pr(X - .12, o.y, z), p1 = e.pr(X + .12, o.y - h, z); if (!p0 || !p1) continue; const f = cl(1 - z / 6.5); x.fillStyle = A((i + j) % 3 ? e.c1 : e.c2, .42 * f); x.fillRect(p0[0], p1[1], p1[0] - p0[0], p0[1] - p1[1]); x.fillStyle = A('#ffffff', .8 * f); x.fillRect(p0[0], p1[1], p1[0] - p0[0], 2); } }; };
L.city = (o = {}) => { const mk = (side, z) => ({ side, z, w: rr(.35, .8), h: rr(.7, 2.2), win: Array.from({ length: 24 }, () => R() < .55) }), bs = []; for (let i = 0; i < 13; i++) { bs.push(mk(-1, .8 + i * .7)); bs.push(mk(1, .8 + i * .7 + .35)); }
  return e => { const x = e.x; for (const b of bs) { b.z += e.v * e.dt * .6; if (b.z > 9.7) Object.assign(b, mk(b.side, b.z - 9.2)); } const far = 9.5; bs.slice().sort((a, c) => c.z - a.z).forEach(b => { const X0 = b.side * 1.05, X1 = b.side * (1.05 + b.w), yt = .8 - b.h, f = cl(1 - b.z / far), p = [e.pr(X0, yt, b.z), e.pr(X1, yt, b.z), e.pr(X1, .8, b.z), e.pr(X0, .8, b.z)]; if (p.some(q => !q)) return;
    path(x, p); x.closePath(); x.fillStyle = '#07090d'; x.fill(); x.strokeStyle = A(e.c1, f * e.a); x.lineWidth = 1.4; x.stroke(); const inner = [e.pr(X0, yt, b.z + .6), e.pr(X0, .8, b.z + .6)]; if (inner[0]) { x.strokeStyle = A(e.c1, f * e.a * .5); stroke3(e, [p[0], inner[0], inner[1], p[3]]); }
    x.fillStyle = A(e.c2, f * e.a * .9); b.win.forEach((on, k) => { if (!on) return; const u = (k % 4 + .5) / 4, v = (((k / 4) | 0) + .5) / 6, px = p[0][0] + (p[1][0] - p[0][0]) * u, py = p[0][1] + (p[3][1] - p[0][1]) * v, sz = Math.max(1, p[0][2] * .018); x.fillRect(px, py, sz, sz * 1.3); }); }); }; };
L.rays = (o = {}) => { o = { n: 14, a: .35, ...o };
  return e => { const x = e.x, R0 = Math.hypot(e.W, e.H) / 2, g = x.createRadialGradient(e.cx, e.cy, 0, e.cx, e.cy, R0); g.addColorStop(0, A(e.c1, o.a * e.a)); g.addColorStop(1, A(e.c1, 0)); x.globalCompositeOperation = 'lighter'; x.fillStyle = g; for (let k = 0; k < o.n; k++) { const an = e.t * .2 * (k % 2 ? -1 : 1) + k * TAU / o.n, w = .03 + .02 * Math.sin(e.t * 1.7 + k * 2.1); x.beginPath(); x.moveTo(e.cx, e.cy); x.arc(e.cx, e.cy, R0, an - w, an + w); x.closePath(); x.fill(); } }; };
L.scan = () => e => { const x = e.x; x.fillStyle = A('#000000', .18 * e.a); for (let y = (e.t * 30) % 4; y < e.H; y += 4) x.fillRect(0, y, e.W, 1.3); if (R() < .07) { const y = rr(0, e.H), h = rr(4, 40); x.globalCompositeOperation = 'lighter'; x.fillStyle = A(e.c2, .14 * e.a); x.fillRect(rr(-30, 30), y, e.W, h); x.fillStyle = A(e.c1, .1 * e.a); x.fillRect(rr(-30, 30), y + 3, e.W, h * .6); } };
L.ribbons = (o = {}) => { o = { n: 4, ...o };
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; x.lineCap = 'round'; for (let b = 0; b < o.n; b++) { const z = 1.8 + b * .7, pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40; pts.push(e.pr((u - .5) * 6, Math.sin(u * 4 + e.t * (.8 + b * .2) + b * 1.7) * .6 * (1 + b * .1) + Math.cos(u * 9 - e.t * 1.4) * .08, z)); } x.strokeStyle = A(b % 2 ? e.c1 : e.c2, e.a * .22); x.lineWidth = 14 - b * 2; stroke3(e, pts); x.strokeStyle = A('#ffffff', e.a * .6); x.lineWidth = 1.6; stroke3(e, pts); } }; };
L.pillars = () => { let off = 0;
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; off += e.v * e.dt * .5; for (let side = -1; side <= 1; side += 2) for (let i = 0; i < 12; i++) { const z = .6 + mod(i * .9 + off, 10.8), X = side * 1.0, hgt = .8 + .9 * (Math.sin(e.t * 1.4 + i * 1.3) * .5 + .5), p0 = e.pr(X, .8, z), p1 = e.pr(X, .8 - hgt, z); if (!p0 || !p1) continue; const f = cl(1 - z / 10.8), w = p0[2] * .05, g = x.createLinearGradient(0, p1[1], 0, p0[1]); g.addColorStop(0, A(e.c2, 0)); g.addColorStop(1, A(i % 2 ? e.c1 : e.c2, .8 * f * e.a)); x.fillStyle = g; x.fillRect(p0[0] - w, p1[1], w * 2, p0[1] - p1[1]); x.fillStyle = A('#ffffff', .7 * f * e.a); x.fillRect(p0[0] - w * .25, p1[1], w * .5, p0[1] - p1[1]); } }; };
L.prism = () => e => { const x = e.x, R0 = Math.hypot(e.W, e.H) * .6; x.globalCompositeOperation = 'lighter'; for (let k = 0; k < 18; k++) { const hue = mod(k * 20 + e.t * 40, 360), an = -.3 + k / 18 * TAU * .55 + Math.sin(e.t * .4) * .3 + e.t * .12, g = x.createRadialGradient(e.cx, e.cy, 0, e.cx, e.cy, R0), c = hsl(0, 0, 45 + (k % 3) * 20); g.addColorStop(0, A(c, .55 * e.a)); g.addColorStop(1, A(c, 0)); x.fillStyle = g; x.beginPath(); x.moveTo(e.cx, e.cy); x.arc(e.cx, e.cy, R0, an - .045, an + .045); x.closePath(); x.fill(); } };
L.planets = (o = {}) => { o = { z: 3.2, r: .55, ...o };
  return e => { const x = e.x, cx = e.cx + Math.cos(e.t * .1) * e.W * .04, cy = e.cy, r = e.f * o.r / o.z; x.save(); x.lineCap = 'butt'; const ring = (a0, a1) => { x.strokeStyle = A(e.c2, .5 * e.a); x.lineWidth = r * .22; x.beginPath(); x.ellipse(cx, cy, r * 1.9, r * .5, -.35, a0, a1); x.stroke(); x.strokeStyle = A('#ffffff', .35 * e.a); x.lineWidth = r * .04; x.beginPath(); x.ellipse(cx, cy, r * 2.15, r * .57, -.35, a0, a1); x.stroke(); };
    ring(Math.PI, TAU); const moon = k => { const an = e.t * (.5 + k * .3) + k * 3, mx = cx + Math.cos(an) * r * 2.4, my = cy + Math.sin(an) * r * .5 - r * .2, z = Math.sin(an); return { mx, my, z, mr: r * (.13 + k * .05) * (1 + z * .25) }; }, ms = [moon(0), moon(1)];
    const dm = m => { const g = x.createRadialGradient(m.mx - m.mr * .3, m.my - m.mr * .3, m.mr * .1, m.mx, m.my, m.mr); g.addColorStop(0, '#ffffff'); g.addColorStop(1, mix(e.c1, '#000000', .6)); x.fillStyle = g; x.beginPath(); x.arc(m.mx, m.my, m.mr, 0, TAU); x.fill(); }; ms.filter(m => m.z < 0).forEach(dm);
    const g = x.createRadialGradient(cx - r * .35, cy - r * .35, r * .1, cx, cy, r); g.addColorStop(0, mix(e.c2, '#ffffff', .5)); g.addColorStop(.5, e.c1); g.addColorStop(1, mix(e.c1, '#000000', .85)); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, TAU); x.fill(); x.save(); x.clip(); x.fillStyle = A('#ffffff', .1 * e.a); for (let k = -4; k < 5; k++) x.fillRect(cx - r, cy + k * r * .22 + Math.sin(e.t * .5 + k) * r * .03, r * 2, r * .08); x.restore();
    ring(0, Math.PI); ms.filter(m => m.z >= 0).forEach(dm); const h = x.createRadialGradient(cx, cy, r, cx, cy, r * 1.5); h.addColorStop(0, A(e.c2, .3 * e.a)); h.addColorStop(1, A(e.c2, 0)); x.fillStyle = h; x.beginPath(); x.arc(cx, cy, r * 1.5, 0, TAU); x.fill(); x.restore(); }; };
L.fire = (o = {}) => { o = { n: 140, ...o }; const ps = [];
  return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; for (let i = 0, n = Math.round(e.dt * 180); i < n; i++) if (ps.length < o.n && R() < e.a) ps.push({ x: rr(.02, .98) * e.W, y: e.H + 10, vx: rr(-20, 20), vy: -rr(120, 330), l: 1, s: rr(10, 34) });
    for (let i = ps.length - 1; i >= 0; i--) { const p = ps[i]; p.l -= e.dt * .55; if (p.l <= 0) { ps.splice(i, 1); continue; } p.x += (p.vx + Math.sin(e.t * 4 + i) * 30) * e.dt; p.y += p.vy * e.dt; const r = p.s * (.4 + p.l), g = x.createRadialGradient(p.x, p.y, 0, p.x, p.y, r); g.addColorStop(0, A(p.l > .6 ? '#ffffff' : e.c2, p.l * .5)); g.addColorStop(.5, A(e.c1, p.l * .3)); g.addColorStop(1, A(e.c1, 0)); x.fillStyle = g; x.fillRect(p.x - r, p.y - r, r * 2, r * 2); } }; };
L.haze = (o = {}) => { o = { k: 1, ...o }; return e => { const x = e.x; x.globalCompositeOperation = 'lighter'; for (let k = 0; k < 5; k++) { const px = e.W * (.5 + .4 * Math.sin(e.t * .13 + k * 2.1)), py = e.H * (.5 + .3 * Math.cos(e.t * .17 + k * 1.7)), r = Math.max(e.W, e.H) * (.3 + .06 * Math.sin(e.t * .3 + k)), g = x.createRadialGradient(px, py, 0, px, py, r); g.addColorStop(0, A(k % 2 ? e.c1 : e.c2, .09 * e.a * o.k)); g.addColorStop(1, A(e.c1, 0)); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2); } }; };

// ---------- 58 walkout-scènes: [naam, tint, lagen] ----------
const SCENES = [
  ['SPELERSTUNNEL', 215, () => [L.floor(), L.tunnel({ ribs: 1 }), L.lights(), L.flashes({ rate: 7 }), L.stars({ n: 60 })]],
  ['NEON PITCH', 150, () => [L.stars({ n: 80 }), L.rays({ n: 10, a: .22 }), L.pitch({ spin: .18 })]],
  ['CHAMPIONS NIGHT', 225, () => [L.stars({ n: 120 }), L.cones({ n: 5 }), L.gates({ n: 6 }), L.lights({ rows: 1, cols: 8, y: [-1.2] }), L.flashes({ rate: 10 })]],
  ['HAT-TRICK', 285, () => [L.stars({ n: 90 }), L.torus({ z: 3.4, spin: .9 }), L.torus({ R: 1, r: .1, z: 3.4, spin: -.6, nu: 36, nv: 6 }), L.orbiters({ n: 5, z: 3.4 })]],
  ['STADION VUUR', 18, () => [L.floor({ ceil: 0 }), L.lights({ rows: 2, cols: 7 }), L.fire({ n: 120 }), L.flashes({ rate: 5 })]],
  ['SYNTHWAVE', 312, () => [L.stars({ n: 50 }), L.sun(), L.terrain()]],
  ['KOMEETSTAART', 190, () => [L.stars({ n: 160, len: 14, k: 1.6 }), L.vortex({ n: 110, tw: .8 }), L.lissa({ a: 2, b: 3, c: 4 })]],
  ['WINNAARS-DNA', 160, () => [L.stars({ n: 70, alt: 1 }), L.helix({ axis: 'z', r: .9, turns: 5 }), L.haze()]],
  ['GALAXY KICKOFF', 262, () => [L.stars({ n: 60 }), L.galaxy(), L.planets({ z: 5.5, r: .5 })]],
  ['ZWART GAT', 272, () => [L.stars({ n: 70 }), L.blackhole(), L.haze({ k: .7 })]],
  ['HEXAGRID', 175, () => [L.hex(), L.tunnel({ sides: 6, aspect: 1.5, rad: 1.3 }), L.scan()]],
  ['MATRIX SCORE', 130, () => [L.floor({ ceil: 0, cols: 12 }), L.glyphs({ n: 46 }), L.scan()]],
  ['LASERSHOW', 330, () => [L.tunnel({ ribs: 1, alt: 1 }), L.lasers({ n: 8 }), L.flashes({ rate: 6 }), L.haze()]],
  ['DONDERSLAG', 215, () => [L.stars({ n: 50 }), L.rain({ kind: 'rain', n: 170 }), L.lightning({ rate: .6 }), L.haze({ k: .6 })]],
  ['VUURWERK', 50, () => [L.stars({ n: 50 }), L.terrain({ type: 'ocean', amp: .5, y: .85 }), L.fireworks({ rate: 1.2 })]],
  ['KUBUSREGEN', 200, () => [L.stars({ n: 50 }), L.floor({ ceil: 0 }), L.cubes({ n: 26 })]],
  ['KRISTAL', 190, () => [L.prism(), L.poly({ shape: 'icosa', size: .85, z: 3.3, spin: .7 }), L.orbiters({ n: 4, z: 3.3 })]],
  ['DODECAËDER', 330, () => [L.stars({ n: 80 }), L.tunnel({ sides: 5, aspect: 1.3, spin: .15 }), L.poly({ shape: 'dodeca', size: .6, z: 3, spin: 1 })]],
  ['TORUSKNOOP', 100, () => [L.stars({ n: 80 }), L.knot({ p: 2, q: 3, size: 1 }), L.lissa({ a: 1, b: 2, c: 3, n: 100 })]],
  ['WERELDBOL', 205, () => [L.stars({ n: 50 }), L.sphere({ r: .9 }), L.orbiters({ n: 6, z: 3.2 }), L.lights({ rows: 1, cols: 5, y: [-1.4] })]],
  ['SATURNUS', 35, () => [L.stars({ n: 120, len: 3 }), L.planets(), L.rain({ kind: 'dust', n: 80 })]],
  ['NOORDERLICHT', 150, () => [L.stars({ n: 60 }), L.aurora(), L.terrain({ amp: .5, y: .9, rows: 16 })]],
  ['SNEEUWSTORM', 200, () => [L.cones({ n: 4 }), L.floor({ ceil: 0, cols: 12 }), L.rain({ kind: 'snow', n: 220 })]],
  ['DOELPUNT!', 120, () => [L.floor({ ceil: 0 }), L.goal(), L.flashes({ rate: 8 }), L.lights({ rows: 1, cols: 6, y: [-1.3] })]],
  ['VRIJE TRAP', 28, () => [L.stars({ n: 50 }), L.pitch({ spin: -.12, tilt: .65, z: 4 }), L.ballfly(), L.shock({ rate: .6, y: .8, z: 3.6 })]],
  ['PENALTY', 355, () => [L.gates({ n: 7, rad: .8 }), L.lights({ rows: 1, cols: 5, y: [-1.3] }), L.ballfly(), L.flashes({ rate: 6 })]],
  ['HOEKSCHOP', 95, () => [L.stars({ n: 40 }), L.pitch({ spin: .3, tilt: .8, s: .034 }), L.fireworks({ rate: .8 }), L.flashes({ rate: 5 })]],
  ['CAMERAFLITS', 200, () => [L.tunnel({ aspect: 1.5 }), L.lights({ rows: 2, cols: 8 }), L.flashes({ rate: 22 }), L.stars({ n: 40 })]],
  ['KLEURENPRISMA', 300, () => [L.prism(), L.rays({ n: 20, a: .2 }), L.tunnel({ sides: 3, aspect: 1.2, spin: .3 })]],
  ['RADARSCHERM', 140, () => [L.stars({ n: 40 }), L.radar(), L.lasers({ n: 4, floor: 1 })]],
  ['EQUALIZER', 310, () => [L.floor({ ceil: 0 }), L.eq(), L.lasers({ n: 6 })]],
  ['SKYLINE', 230, () => [L.stars({ n: 70 }), L.floor({ ceil: 0, cols: 6 }), L.city()]],
  ['LICHTPILAREN', 190, () => [L.floor({ ceil: 0 }), L.pillars(), L.haze({ k: .8 })]],
  ['KAARTENSTORM', 48, () => [L.rays({ n: 12, a: .25 }), L.ghostcards({ n: 11 }), L.stars({ n: 70 })]],
  ['CONFETTI KANON', 340, () => [L.shock({ rate: 1.2 }), L.confetti({ n: 150 }), L.fireworks({ rate: .6 })]],
  ['ORBIT', 255, () => [L.stars({ n: 70 }), L.tunnel({ sides: 8, aspect: 1.2, spin: .1 }), L.orbiters({ n: 9, z: 2.8 })]],
  ['GLITCH', 160, () => [L.tunnel({ twist: .18, aspect: 1.4 }), L.cubes({ n: 14 }), L.scan()]],
  ['WARPSPRONG', 205, () => [L.stars({ n: 200, len: 18, k: 2.4 }), L.vortex({ n: 90, tw: .5 }), L.gates({ n: 5 })]],
  ['LINTEN', 322, () => [L.stars({ n: 50 }), L.ribbons(), L.aurora({ bands: 2 })]],
  ['VULKAAN', 10, () => [L.terrain({ amp: 1.4 }), L.rain({ kind: 'embers', n: 150 }), L.fire({ n: 90 })]],
  ['ONDERWATER', 190, () => [L.terrain({ type: 'ocean', amp: .7, y: .9 }), L.cones({ n: 5 }), L.rain({ kind: 'bubbles', n: 90 })]],
  ['WOESTIJN', 32, () => [L.sun({ r: .6 }), L.terrain({ amp: .5, y: .85 }), L.rain({ kind: 'dust', n: 100 })]],
  ['CYBERPOORT', 175, () => [L.floor(), L.gates({ shape: 'square', n: 6 }), L.glyphs({ n: 22 }), L.scan()]],
  ['SPIRAAL', 290, () => [L.stars({ n: 60 }), L.tunnel({ sides: 3, twist: .35, n: 22, aspect: 1.3 }), L.haze()]],
  ['TWISTER', 245, () => [L.vortex({ n: 150, tw: 2.2, r1: .9 }), L.lightning({ rate: .5 }), L.haze({ k: .6 })]],
  ['DISCOBAL', 300, () => [L.sphere({ dots: 1, r: .85, nlat: 9, nlon: 16 }), L.lasers({ n: 8 }), L.flashes({ rate: 8 })]],
  ['STORMVLOED', 205, () => [L.terrain({ type: 'ocean', amp: 1, y: .85, rows: 20 }), L.lightning({ rate: .7 }), L.rain({ kind: 'rain', n: 140 })]],
  ['TIKI-TAKA', 135, () => [L.stars({ n: 40 }), L.pitch({ spin: .1, tilt: .75 }), L.lissa({ a: 3, b: 4, c: 2, n: 120, z: 3.6 })]],
  ['COMEBACK', 8, () => [L.tunnel({ sides: 8, aspect: 1.1, spin: -.2, alt: 1 }), L.lights({ rows: 1, cols: 7, y: [-1.2] }), L.rays({ n: 14, a: .3 })]],
  ['LAST MINUTE', 0, () => [L.gates({ n: 7 }), L.shock({ rate: 1.5 }), L.lights(), L.flashes({ rate: 14 })]],
  ['SUPERSUB', 270, () => [L.cones({ n: 4 }), L.poly({ shape: 'cube', size: .5, z: 3, spin: 1.2, count: 3, orbit: 1 }), L.ghostcards({ n: 6 })]],
  ['ABSEITS', 180, () => [L.tunnel({ sides: 2, n: 22, gap: .5, rad: 1.1, aspect: 2.4, spin: .12, lw: 2 }), L.scan(), L.stars({ n: 40, alt: 1 })]],
  ['WERELDBEKER', 44, () => [L.rays({ n: 20, a: .3 }), L.sphere({ r: .7, nlat: 6, nlon: 10 }), L.confetti({ n: 90 }), L.lights({ rows: 1, cols: 6, y: [-1.3] })]],
  ['DERBY DAY', 350, () => [L.city(), L.cones({ n: 4 }), L.fire({ n: 70 }), L.flashes({ rate: 9 })]],
  ['KAMPIOEN', 52, () => [L.lights(), L.gates({ n: 5 }), L.poly({ shape: 'football', size: .6, z: 3, spin: 1.1 }), L.confetti({ n: 80 }), L.fireworks({ rate: .8 })]],
  ['GOUDEN EEUW', 42, () => [L.sun({ r: .55, y: -.05 }), L.pillars(), L.rays({ n: 16, a: .25 })]],
  ['STORM FC', 225, () => [L.cones({ n: 5 }), L.vortex({ n: 90, tw: 1.4 }), L.lightning({ rate: .55 }), L.rain({ kind: 'rain', n: 90 })]]
];
// ---------- 12 onthulling-effecten achter het cijfer ----------
const REVEALS = [
  ['SCHOKGOLF', 200, () => [L.shock({ rate: 1.6, y: .6, z: 2.6 }), L.rays({ n: 18, a: .5 })]],
  ['VUURWERKFINALE', 48, () => [L.fireworks({ rate: 3 }), L.stars({ n: 40, k: .4 })]],
  ['BLIKSEMSLAG', 215, () => [L.lightning({ rate: 1.4 }), L.rays({ n: 10 })]],
  ['KONFETTI', 330, () => [L.confetti({ n: 150 }), L.rays({ n: 12, a: .25 })]],
  ['ORBIT', 180, () => [L.orbiters({ n: 9, z: 2.6 }), L.gates({ n: 4 })]],
  ['DRAAIKOLK', 260, () => [L.vortex({ n: 130, tw: 1.2 }), L.lissa({ n: 120 })]],
  ['PRISMA', 300, () => [L.prism(), L.sphere({ r: .8, nlat: 5, nlon: 8 })]],
  ['LICHTPILAREN', 160, () => [L.pillars(), L.floor({ ceil: 0 })]],
  ['DISCO', 320, () => [L.sphere({ dots: 1, r: .8 }), L.flashes({ rate: 12 })]],
  ['VOETBAL', 40, () => [L.poly({ shape: 'football', size: .95, z: 3.4, spin: .7 }), L.rays({ n: 14, a: .25 })]],
  ['KRISTAL', 190, () => [L.poly({ shape: 'icosa', size: .8, z: 3.2, spin: .6, count: 2, orbit: 1.1 }), L.haze()]],
  ['NOORDERLICHT', 150, () => [L.aurora({ bands: 3 }), L.stars({ n: 50, k: .5 })]]
];

// ---------- runtime ----------
const build = (lib, i, accent) => {
  const [name, hue, mk] = lib[mod(i | 0, lib.length)], layers = mk();
  const env = { x: null, W: 0, H: 0, cx: 0, cy: 0, f: 0, t: 0, dt: .016, v: 1, a: 1, c1: '#ffffff', c2: '#ffffff', pr: null };
  env.c1 = mix('#ffffff', accent, .10); env.c2 = mix(hsl(0, 0, 42 + (hue % 5) * 9), accent, .16);
  env.pr = (X, Y, Z) => (Z < .06 ? null : [env.cx + X * env.f / Z, env.cy + Y * env.f / Z, env.f / Z]);
  return { name, draw(x, W, H, t, dt, a, v) {
    env.x = x; env.W = W; env.H = H; env.cx = W / 2; env.cy = H / 2; env.f = Math.min(W, H) * .9; env.t = t; env.dt = Math.min(.13, Math.max(.001, dt)); env.a = a; env.v = v == null ? .5 + 4.5 * (Math.min(t, 16) / 16) ** 2.2 : v;
    for (const l of layers) { x.save(); try { l(env); } catch (err) { /* een laag mag nooit de hele animatie stoppen */ } x.restore(); } } };
};
globalThis.SC_ANIMS = {
  count: SCENES.length, names: SCENES.map(s => s[0]), revealCount: REVEALS.length,
  create: (i, accent) => build(SCENES, i, accent), createReveal: (i, accent) => build(REVEALS, i, accent),
  // voorbeeldweergave voor de Animaties-tab: still() tekent een stilstaand beeld, play()/stop() animeren live
  preview(cv, i, accent) {
    const sc = build(SCENES, i, accent), x = cv.getContext('2d'); let t = 0, raf = 0, last = 0;
    const frame = dt => { t += dt; x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.fillStyle = '#050507'; x.fillRect(0, 0, cv.width, cv.height); sc.draw(x, cv.width, cv.height, t, dt, Math.min(1, t / .8), 3.2); };
    const loop = n => { frame(Math.min(.05, (n - last) / 1000)); last = n; raf = requestAnimationFrame(loop); };
    return { name: sc.name, still(sec = 5) { for (let k = 0; k < sec * 10; k++) frame(.1); }, play() { cancelAnimationFrame(raf); last = performance.now(); raf = requestAnimationFrame(loop); }, stop() { cancelAnimationFrame(raf); raf = 0; } };
  }
};
})();
