(() => {
const LB_URL = ''; // optioneel: eigen server voor de online ranglijst
// varianten: [grondtoon, golfvorm, tempo, achtergrondstijl]
const VAR = [[0,'sawtooth',1,0],[2,'square',.96,1],[5,'triangle',1.04,2],[7,'sawtooth',.92,3],[-2,'square',1,4],[3,'triangle',1.08,5],[9,'sawtooth',.97,6],[-5,'square',1.03,7],[4,'triangle',.94,8],[1,'sawtooth',1.06,9],[6,'triangle',1.02,10],[-3,'sawtooth',.95,11]];
const GRADE = /^(10|[1-9])[,.]\d$/, GRADE_I = /^(10|[1-9])$/, GRADE_L = /^[OVG]$/;
const own = e => [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').replace(/\s+/g, ' ').trim();
const cls = n => (typeof n.className === 'string' ? n.className : '');
// cijfer-element: "7,5" (of een heel cijfer zoals "8" als de klasse op een cijfer lijkt)
const isGradeEl = e => { const t = own(e); if (GRADE.test(t)) return true; const int = GRADE_I.test(t), let_ = GRADE_L.test(t); if (!int && !let_) return false;
  for (let n = e, i = 0; n && i < 3; i++, n = n.parentElement) { if (/cijfer|resultaat|grade|score|badge/i.test(cls(n))) return true; if (let_ && /(on)?voldoende|goed/i.test((n.getAttribute('title') || '') + (n.getAttribute('aria-label') || ''))) return true; } return false; };
const shield = () => { const d = document.createElement('div'); d.style.cssText = 'position:fixed;inset:0;z-index:100001;background:transparent'; ['click','mousedown','mouseup','pointerdown','pointerup','dblclick'].forEach(t => d.addEventListener(t, ev => { ev.stopPropagation(); ev.preventDefault(); }, true)); document.body.append(d); setTimeout(() => d.remove(), 450); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fit = (base, s, thr = 11) => (s.length <= thr ? base : Math.max(9, Math.floor(base * thr / s.length)));
const fz = (e, px) => { e.style.fontSize = px + 'px'; return e; };
// lichte geluidjes voor alle knoppen
let sx, lastHover;
const sfx = (f, d = .07, v = .035, type = 'sine', f2) => { try { sx = sx || new AudioContext(); if (sx.state === 'suspended') sx.resume(); const t = sx.currentTime, o = sx.createOscillator(), g = sx.createGain(); o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(sx.destination); o.start(t); o.stop(t + d + .02); } catch (e) {} };
const BTN = '.sc-open,.sc-re,.sc-fab,.sc-btn,.sc-tabs button,.sc-slot,.sc-h .x,.sp-side button';
let lastT = 0;
document.addEventListener('mouseover', e => { if (!(e.movementX || e.movementY)) return; const b = e.target.closest && e.target.closest(BTN), n = performance.now(); if (b && b !== lastHover) { lastHover = b; if (n - lastT > 250) { lastT = n; sfx(1100, .04, .01); } } else if (!b) lastHover = null; });
const OURS = '.sp-ov,.sc-m,.sc-toasts,.sc-open,.sc-re,.sc-fab';
document.addEventListener('selectstart', e => { const t = e.target.nodeType === 3 ? e.target.parentElement : e.target; if (t && t.closest && t.closest(OURS) && !t.closest('input')) e.preventDefault(); }, true);
document.addEventListener('dragstart', e => { if (e.target.closest && e.target.closest(OURS)) e.preventDefault(); }, true);
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest(BTN); if (b) sfx(520, .09, .04, 'triangle', 780); }, true);
const LET = { O: 4.5, V: 6.5, G: 8.5 };
const num = g => (LET[g] !== undefined ? LET[g] : parseFloat(String(g).replace(',', '.')));
const dn = d => (/^[A-Za-z]{2,4}$/.test(d) ? d.toUpperCase() : d);
const docOf = c => dn((S.rooster && S.rooster[canon(c.vak)]) || c.docent || '');
const rar = g => { const n = num(g); return n < 5.5 ? 0 : n < 7.5 ? 1 : n < 9 ? 2 : 3; };
const RN = ['ONVOLDOENDE', 'NORMAAL', 'GOUD', 'ICON'], RC = ['#b07a4a', '#c8c8d0', '#ffd400', '#7fe3ff'];
const stars = g => { const n = Math.round(num(g)) / 2; return '★'.repeat(Math.floor(n)) + (n % 1 ? '⯨' : '') + '☆'.repeat(5 - Math.ceil(n)); };
const h = (tag, cls = '', t) => { const d = document.createElement(tag); if (cls) d.className = cls; if (t != null) d.textContent = t; return d; };
const ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v6h6"/></svg>';

// ---------- data store: 1 kaart per toets ----------
const S = { cards: {}, club: null, rooster: {} };
const save = () => chrome.storage.local.set({ cards4: S.cards, club: S.club, rooster: S.rooster });
const load = () => new Promise(r => chrome.storage.local.get(['cards4', 'club', 'rooster'], d => { S.cards = d.cards4 || {}; S.club = d.club || null; S.rooster = d.rooster || {}; if (S.club) { S.club.lineup = S.club.lineup.map(id => (S.cards[id] ? id : null)); S.club.ach = S.club.ach || {}; if (S.club.earned == null) S.club.earned = S.club.points; S.club.since = S.club.since || Date.now(); S.club.streak = S.club.streak || 0; S.club.lastClaim = S.club.lastClaim || 0; } r(); }));
const norm = s => s.toLowerCase().replace(/\s+/g, ' ').trim();
const ppm = c => Math.max(1, Math.round(num(c.grade) ** 2 * (parseFloat(c.weging) || 1) / 10));
const mult = () => 1 + .1 * (S.club.level - 1);
const total = () => Math.round(S.club.lineup.reduce((a, id) => a + (S.cards[id] ? ppm(S.cards[id]) : 0), 0) * mult() * chemMult());
const upCost = () => Math.round(100 * S.club.level ** 1.7);
function accrue() { if (!S.club) return; const now = Date.now(), dt = Math.min(now - S.club.last, 6048e5), g = total() * dt / 6e4; S.club.points += g; S.club.earned = (S.club.earned || 0) + g; S.club.last = now; }
setInterval(() => { accrue(); save(); }, 10000);
const BAD = /kut|kanker|tering|tyfus|hoer|slet|neger|nigg|fuck|shit|bitch|cunt|homo|mongool|lul|klootzak|nazi|hitler|flikker|\bpik|fag|rot ?op|sukkel|idioot|debiel/;
const cleanName = n => { const t = n.toLowerCase().replace(/0/g, 'o').replace(/1/g, 'i').replace(/3/g, 'e').replace(/4/g, 'a').replace(/[@]/g, 'a').replace(/\$/g, 's').replace(/[^a-z ]/g, ''); return !BAD.test(t) && !BAD.test(t.replace(/ /g, '')); };

// tilt: de muispositie wordt gemeten op een vaste rechthoek (bij mouseenter) zodat het element niet gaat flikkeren onder de muis
function tilt(el, k = 14, z, target) {
  k *= 1.5; const t = target || el, base = z === undefined ? '' : `translateZ(${z}px)`; t.classList.add('sc-tilt'); t.style.transition = 'box-shadow .2s'; if (base) t.style.transform = base;
  let r = null, tx = 0, ty = 0, cx = 0, cy = 0, cs = 1, ts = 1, raf = 0, hot = false;
  const apply = () => { const rot = `rotateX(${cy.toFixed(2)}deg) rotateY(${cx.toFixed(2)}deg)`; t.style.transform = z !== undefined ? `translateZ(${z + 26 * (cs - 1) / .1}px) ${rot} scale(${cs.toFixed(3)})` : target ? `${rot} scale(${cs.toFixed(3)})` : `perspective(500px) ${rot} scale(${cs.toFixed(3)})`; };
  const step = () => { cx += (tx - cx) * .22; cy += (ty - cy) * .22; cs += (ts - cs) * .22; apply(); if (hot || Math.abs(cx - tx) + Math.abs(cy - ty) + Math.abs(cs - ts) > .01) raf = requestAnimationFrame(step); else { raf = 0; if (!hot) t.style.transform = base; } };
  const go = () => { if (!raf) raf = requestAnimationFrame(step); };
  el.addEventListener('mouseenter', () => { r = el.getBoundingClientRect(); hot = true; ts = 1.1; go(); });
  el.addEventListener('mousemove', e => { r = r || el.getBoundingClientRect(); const px = clamp01((e.clientX - r.left) / r.width), py = clamp01((e.clientY - r.top) / r.height); tx = (px - .5) * k; ty = (.5 - py) * k; t.style.setProperty('--mx', px * 100 + '%'); t.style.setProperty('--my', py * 100 + '%'); go(); });
  el.addEventListener('mouseleave', () => { r = null; hot = false; tx = ty = 0; ts = 1; go(); });
  return el;
}
// ---------- kaart ----------
function cardEl(c) {
  const d = h('div', 'sp-card sp-rar-' + rar(c.grade)), top = h('div'), mid = h('div');
  top.append(h('div', 'g', c.grade), h('div', 'r', RN[rar(c.grade)]));
  mid.append(fz(h('div', 'v', c.vak), fit(21, c.vak)), h('div', 'm', 'Docent: ' + (docOf(c) || '-')), h('hr'), h('div', 'm', c.onderwerp), h('div', 'm', 'Weging ' + c.weging));
  d.append(top, mid, h('div', 's', stars(c.grade)), h('div', 'foil')); const w = h('div', 'sp-cw'); w.append(d); return tilt(w, 16, undefined, d);
}
function png() {
  const cs = Object.values(S.cards).filter(c => c.opened), cols = Math.min(4, cs.length || 1), rows = Math.ceil(cs.length / cols) || 1, cw = 230, ch = 330, g = 20;
  const cv = document.createElement('canvas'); cv.width = cols * (cw + g) + g; cv.height = rows * (ch + g) + g; const x = cv.getContext('2d');
  x.fillStyle = '#050507'; x.fillRect(0, 0, cv.width, cv.height);
  cs.forEach((c, i) => {
    const px = g + (i % cols) * (cw + g), py = g + Math.floor(i / cols) * (ch + g), col = RC[rar(c.grade)], gr = x.createLinearGradient(px, py, px + cw, py + ch);
    gr.addColorStop(0, col + '55'); gr.addColorStop(.7, '#0b0b0e'); x.fillStyle = gr; x.strokeStyle = col; x.lineWidth = 1.5; x.beginPath(); x.roundRect(px, py, cw, ch, 16); x.fill(); x.stroke();
    x.fillStyle = '#fff'; x.font = '800 58px sans-serif'; x.fillText(c.grade, px + 18, py + 88);
    x.font = '800 ' + fit(21, c.vak) + 'px sans-serif'; x.fillText(c.vak.toUpperCase(), px + 18, py + 200);
    x.fillStyle = '#aeaeb6'; x.font = '12px sans-serif'; x.fillText('Docent: ' + (docOf(c) || '-'), px + 18, py + 222); x.fillText(c.onderwerp.slice(0, 32), px + 18, py + 250); x.fillText('Weging ' + c.weging, px + 18, py + 270);
    x.fillStyle = col; x.font = '20px sans-serif'; x.fillText(stars(c.grade), px + 18, py + 308);
  });
  const a = document.createElement('a'); a.href = cv.toDataURL('image/png'); a.download = 'mijn-kaarten.png'; a.click();
}

// ---------- muziek: hele animatie door, anders per cijfer ----------
function music(v, grade) {
  const [semi, wave, tv] = VAR[v], tier = rar(grade), ctx = new AudioContext(), root = 55 * 2 ** (semi / 12), m = ctx.createGain(), comp = ctx.createDynamicsCompressor();
  const sc = tier < 2 ? [0, 3, 7, 10] : [0, 4, 7, 12], base = (76 + tier * 12) * tv; m.gain.value = .5; m.connect(comp).connect(ctx.destination);
  const nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const tone = (f, t, d, type, vol) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(m); o.start(t); o.stop(t + d + .05); };
  const kick = (t, vol = .8, d = .25) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(40, t + .15); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(m); o.start(t); o.stop(t + d); };
  const hat = (t, vol) => { const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = nb; f.type = 'highpass'; f.frequency.value = 7000; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.0001, t + .05); s.connect(f).connect(g).connect(m); s.start(t); s.stop(t + .06); };
  const T0 = ctx.currentTime + .05, lp = ctx.createBiquadFilter(), dg = ctx.createGain(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(140, T0); lp.frequency.exponentialRampToValueAtTime(1400, T0 + 22);
  dg.gain.setValueAtTime(.0001, T0); dg.gain.exponentialRampToValueAtTime(.16, T0 + 3); [0, 7, -7].forEach(d => { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = root; o.detune.value = d; o.connect(lp); o.start(T0); }); lp.connect(dg).connect(m);
  const pads = []; if (tier >= 2) sc.slice(0, 3).forEach(n => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'triangle'; o.frequency.value = root * 4 * 2 ** (n / 12); g.gain.setValueAtTime(.0001, T0); g.gain.exponentialRampToValueAtTime(tier === 3 ? .07 : .04, T0 + 8); o.connect(g).connect(m); o.start(T0); pads.push(g); });
  const rs = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), rg = ctx.createGain(); rs.buffer = nb; rs.loop = true; bp.type = 'bandpass'; bp.Q.value = 2; bp.frequency.setValueAtTime(300, T0 + 9); bp.frequency.exponentialRampToValueAtTime(6000, T0 + 19.4);
  rg.gain.setValueAtTime(.0001, T0 + 9); rg.gain.exponentialRampToValueAtTime(.14, T0 + 19.3); rg.gain.linearRampToValueAtTime(0, T0 + 19.5); rs.connect(bp).connect(rg).connect(m); rs.start(T0 + 9); rs.stop(T0 + 19.6);
  let next = T0, step = 0, alive = true, done = 0; const pat = [0, 1, 2, 3, 2, 1, 3, 2];
  const iv = setInterval(() => { while (alive && next < ctx.currentTime + .3) {
    const el = next - T0, bpm = base * (1 + .8 * Math.min(1, el / 19)), sx = 60 / bpm / 4, drums = el < 19.4;
    if (drums && step % 4 === 0 && el > .8) kick(next); if (drums && step % 2 === 1 && el > 5) hat(next, .08 + el / 250);
    if (el > 1.2) { const n = sc[pat[step % 8]], oct = (el > 12 || tier === 3) ? 8 : 4; tone(root * oct * 2 ** (n / 12), next, sx * 1.8, wave, (drums ? .05 + el / 500 : .04)); }
    next += sx; step++; } }, 80);
  return {
    hit(big) { const t = ctx.currentTime; kick(t, 1, big ? 1.4 : .5); tone(root * 4, t, big ? 3 : .7, 'sawtooth', .1); },
    whoosh() { const t = ctx.currentTime, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = nb; f.type = 'bandpass'; f.Q.value = 1.2; f.frequency.setValueAtTime(400, t); f.frequency.exponentialRampToValueAtTime(5000, t + .7); g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.18, t + .25); g.gain.exponentialRampToValueAtTime(.0001, t + .8); s.connect(f).connect(g).connect(m); s.start(t); s.stop(t + .85); },
    roar(tr) { const t = ctx.currentTime, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(), L = 1.5 + tr; s.buffer = nb; s.loop = true; f.type = 'lowpass'; f.frequency.value = 900 + tr * 500; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.05 + tr * .05, t + .5); g.gain.exponentialRampToValueAtTime(.0001, t + L); s.connect(f).connect(g).connect(m); s.start(t); s.stop(t + L + .1); },
    tick(p) { tone(root * 16 * 2 ** (sc[Math.floor(p * 3.9)] / 12), ctx.currentTime, .06, 'triangle', .06); },
    quiet() { const t = ctx.currentTime; dg.gain.cancelScheduledValues(t); dg.gain.setValueAtTime(Math.max(dg.gain.value, .0002), t); dg.gain.exponentialRampToValueAtTime(.0001, t + .8); pads.forEach(g => { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(Math.max(g.gain.value, .0002), t); g.gain.exponentialRampToValueAtTime(.0001, t + .8); }); alive = false; clearInterval(iv); try { rs.stop(); } catch (e) {} },
    finale() { const t = ctx.currentTime; sc.concat([sc[0] + 12]).forEach(n => { const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter(); o.type = 'sawtooth'; o.frequency.value = root * 4 * 2 ** (n / 12); f.type = 'lowpass'; f.frequency.value = 1300; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.08, t + 1); g.gain.exponentialRampToValueAtTime(.0001, t + 6); o.connect(f).connect(g).connect(m); o.start(t); o.stop(t + 6.2); }); kick(t, 1, 1.5); },
    stop() { if (done) return; done = 1; alive = false; clearInterval(iv); try { m.gain.linearRampToValueAtTime(0, ctx.currentTime + .4); } catch (e) {} setTimeout(() => { try { ctx.close(); } catch (e) {} }, 1500); }
  };
}

// ---------- 2D achtergronden: 12 stijlen, alle bewegen naar achter (diepte) ----------
function bg(style, x, W, H, zs, sp, a, col) {
  x.lineCap = x.lineJoin = 'round'; const R = Math.hypot(W, H) / 2, cx = W / 2, cy = H / 2, C = al => col + Math.round(Math.max(0, Math.min(1, al)) * 255).toString(16).padStart(2, '0');
  const poly = pts => { x.beginPath(); pts.forEach(([a_, b_], k) => (k ? x.lineTo(a_, b_) : x.moveTo(a_, b_))); x.closePath(); x.stroke(); }, dot = (px, py, r) => { x.beginPath(); x.arc(px, py, r, 0, 6.283); x.fill(); };
  zs.forEach((z, i) => {
    zs[i] = z + sp * (.4 + z); if (zs[i] > 1) zs[i] = .03; const q = z ** 2.3, al = Math.min(.55, z * 1.1) * a; x.strokeStyle = x.fillStyle = C(al); x.lineWidth = .5 + z * 2.5;
    if (style === 0) { const w = q * W * .9, hh = w * H / W; x.strokeRect(cx - w / 2, cy - hh / 2, w, hh); }
    else if (style === 1) { for (let k = 0; k < 6; k++) { const an = i * 2.4 + k * 1.05, r1 = q * R, r2 = Math.min(1, z + sp * 7) ** 2.3 * R; x.beginPath(); x.moveTo(cx + Math.cos(an) * r1, cy + Math.sin(an) * r1); x.lineTo(cx + Math.cos(an) * r2, cy + Math.sin(an) * r2); x.stroke(); } }
    else if (style === 2) { const w = q * R * 1.1; poly([[cx, cy - w], [cx + w, cy], [cx, cy + w], [cx - w, cy]]); }
    else if (style === 3) { x.beginPath(); x.arc(cx, cy, q * R, 0, 6.283); x.stroke(); }
    else if (style === 4) { const w = q * R * 1.05; poly([0, 1, 2, 3, 4, 5].map(k => [cx + Math.cos(k * 1.0472) * w, cy + Math.sin(k * 1.0472) * w])); }
    else if (style === 5) { for (let k = 0; k < 8; k++) { const an = i * 2.4 + k * .8; dot(cx + Math.cos(an) * q * R, cy + Math.sin(an) * q * R, .5 + z * 2.2); } }
    else if (style === 6) { const d = q * H * .55, ww = q * W * .8; x.beginPath(); x.moveTo(cx - ww, cy + d); x.lineTo(cx + ww, cy + d); x.moveTo(cx - ww, cy - d); x.lineTo(cx + ww, cy - d); x.stroke(); }
    else if (style === 7) { for (let k = 0; k < 5; k++) { const an = z * 9 + k * 1.2566; dot(cx + Math.cos(an) * q * R, cy + Math.sin(an) * q * R, 1 + z * 2.5); } }
    else if (style === 8) { x.beginPath(); for (let k = 0; k <= 72; k++) { const an = k * .0873, r = q * R * (1 + .07 * Math.sin(an * 6 + z * 30)); k ? x.lineTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r) : x.moveTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r); } x.stroke(); }
    else if (style === 9) { const w = q * R * 1.15; poly([[cx, cy - w], [cx + w * .87, cy + w * .5], [cx - w * .87, cy + w * .5]]); }
    else if (style === 10) { const w = q * R * .8, rot = z * 1.6 + .785; poly([0, 1, 2, 3].map(k => [cx + Math.cos(rot + k * 1.5708) * w * 1.414, cy + Math.sin(rot + k * 1.5708) * w * 1.414])); }
    else { const w = q * R * .9, t = w * .34; poly([[-t, -w], [t, -w], [t, -t], [w, -t], [w, t], [t, t], [t, w], [-t, w], [-t, t], [-w, t], [-w, -t], [-t, -t]].map(([u, v]) => [cx + u, cy + v])); }
  });
  if (style === 0) { x.strokeStyle = C(.1 * a); x.beginPath(); [[0, 0], [W, 0], [0, H], [W, H]].forEach(([p, q]) => { x.moveTo(p, q); x.lineTo(cx + (p ? 1 : -1) * 20, cy + (q ? 1 : -1) * 12); }); x.stroke(); }
  if (style === 6) { x.strokeStyle = C(.12 * a); x.beginPath(); for (let k = -4; k <= 4; k++) { x.moveTo(cx, cy); x.lineTo(cx + k * W / 6, H); x.moveTo(cx, cy); x.lineTo(cx + k * W / 6, 0); } x.stroke(); }
}

// ---------- rondtollende achtergrond na het cijfer (6 versies) ----------
function orbDraw(style, x, W, H, t, col) {
  const cx = W / 2, cy = H / 2, m = Math.min(W, H), a = Math.min(1, t / 1.2), C = al => col + Math.round(Math.max(0, Math.min(1, al * a)) * 255).toString(16).padStart(2, '0');
  x.lineCap = 'round'; x.lineWidth = 2;
  if (style === 0) { for (let k = 0; k < 24; k++) { const an = t * .5 + k * .2618; x.fillStyle = C(k % 2 ? .05 : .11); x.beginPath(); x.moveTo(cx, cy); x.arc(cx, cy, Math.hypot(W, H) / 2, an, an + .1309); x.closePath(); x.fill(); } x.strokeStyle = C(.3); x.beginPath(); x.arc(cx, cy, m * .3, 0, 6.283); x.stroke(); }
  else if (style === 1) { [.2, .3, .42].forEach((r, k) => { const rot = k * 1.0472 + t * .15, ra = m * r * 1.3, rb = m * r * .55; x.strokeStyle = C(.2); x.beginPath(); x.ellipse(cx, cy, ra, rb, rot, 0, 6.283); x.stroke();
      const an = t * (1 + k * .4) * (k % 2 ? -1 : 1), ex = Math.cos(an) * ra, ey = Math.sin(an) * rb; x.fillStyle = C(.9); x.beginPath(); x.arc(cx + ex * Math.cos(rot) - ey * Math.sin(rot), cy + ex * Math.sin(rot) + ey * Math.cos(rot), 6, 0, 6.283); x.fill(); }); }
  else if (style === 2) { for (let k = 0; k < 6; k++) { const r = m * (.14 + k * .06), rot = t * (k % 2 ? .5 : -.5) + k * .3; x.strokeStyle = C(.4 - k * .05); x.beginPath(); for (let j = 0; j <= 6; j++) { const an = rot + j * 1.0472; j ? x.lineTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r) : x.moveTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r); } x.stroke(); } }
  else if (style === 3) { x.fillStyle = C(.7); for (let i = 0; i < 120; i++) { const an = t * (.5 + (i % 5) * .12) + i * 2.4, r = m * (.12 + (i * 7 % 40) / 100); x.beginPath(); x.arc(cx + Math.cos(an) * r, cy + Math.sin(an) * r, 1 + (i % 3), 0, 6.283); x.fill(); } }
  else if (style === 4) { x.lineWidth = 3; for (let k = 0; k < 5; k++) { const r = m * (.2 + k * .045), head = t * (1.2 + k * .15) + k * 1.2566; for (let j = 0; j < 24; j++) { x.strokeStyle = C((1 - j / 24) * .7); x.beginPath(); x.arc(cx, cy, r, head - j * .03 - .03, head - j * .03); x.stroke(); } } }
  else { for (let k = 0; k < 3; k++) { const r = m * (.2 + k * .08) * (1 + .05 * Math.sin(t * 2 + k)) * 1.414, rot = t * (k % 2 ? .6 : -.6) + k * .5 + .785; x.strokeStyle = C(.45 - k * .1); x.beginPath(); for (let j = 0; j <= 4; j++) { const an = rot + j * 1.5708; j ? x.lineTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r) : x.moveTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r); } x.stroke(); } }
}

// ---------- 3D-helpers: echte perspectiefprojectie op canvas ----------
const A = (col, al) => col + Math.round(Math.max(0, Math.min(1, al)) * 255).toString(16).padStart(2, '0');
const mkStars = n => Array.from({ length: n }, () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * .95 + .05 }));
// sterren die op je af vliegen (warp)
function streaks(x, W, H, st, spd, a, col) {
  const cx = W / 2, cy = H / 2; x.lineCap = 'round';
  st.forEach(s => {
    s.z -= spd; if (s.z < .045) { s.z = 1; s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; return; }
    const pr = z => [cx + s.x * W * .5 * .045 / z, cy + s.y * H * .5 * .045 / z], [x1, y1] = pr(s.z), [x0, y0] = pr(Math.min(1, s.z + spd * 6 + .003));
    x.strokeStyle = A(col, (1 - s.z) * a); x.lineWidth = .5 + (1 - s.z) * 2.6; x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke();
  });
}
// draaiende lichtstralen (additief)
function beams(x, W, H, t, col, a, n) {
  const cx = W / 2, cy = H / 2, R = Math.hypot(W, H) / 2, g = x.createRadialGradient(cx, cy, 0, cx, cy, R);
  g.addColorStop(0, A(col, .55 * a)); g.addColorStop(1, A(col, 0)); x.save(); x.globalCompositeOperation = 'lighter'; x.fillStyle = g;
  for (let k = 0; k < n; k++) { const an = t * .22 * (k % 2 ? -1 : 1) + k * 6.283 / n, w = .035 + .025 * Math.sin(t * 1.7 + k * 2.1); x.beginPath(); x.moveTo(cx, cy); x.arc(cx, cy, R, an - w, an + w); x.closePath(); x.fill(); }
  x.restore();
}
// lens flare met anamorfe streep (zoals FIFA walkouts)
function flare(x, W, H, i, col) {
  if (i < .015) return; const cx = W / 2, cy = H / 2; x.save(); x.globalCompositeOperation = 'lighter';
  let g = x.createRadialGradient(cx, cy, 0, cx, cy, Math.min(W, H) * .55 * i + 1); g.addColorStop(0, A('#ffffff', .85 * i)); g.addColorStop(.3, A(col, .45 * i)); g.addColorStop(1, A(col, 0)); x.fillStyle = g; x.fillRect(0, 0, W, H);
  x.translate(cx, cy); x.scale(1, .03); const r = W * .6 * i + 1; g = x.createRadialGradient(0, 0, 0, 0, 0, r); g.addColorStop(0, A('#ffffff', .9 * i)); g.addColorStop(1, A(col, 0)); x.fillStyle = g; x.beginPath(); x.arc(0, 0, r, 0, 6.283); x.fill(); x.restore();
}
// draaiende 3D draadmodellen (octaëder / kubus)
const SHAPES = (() => {
  const cube = [], ce = []; for (let i = 0; i < 8; i++) cube.push([i & 1 ? 1 : -1, i & 2 ? 1 : -1, i & 4 ? 1 : -1]); for (let i = 0; i < 8; i++) for (let b = 1; b < 8; b <<= 1) if (!(i & b)) ce.push([i, i | b]);
  return [{ v: [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], e: [[0, 2], [0, 3], [0, 4], [0, 5], [1, 2], [1, 3], [1, 4], [1, 5], [2, 4], [2, 5], [3, 4], [3, 5]] }, { v: cube, e: ce }];
})();
function wire(x, cx, cy, r, t, col, al, sh) {
  const sp = SHAPES[sh % 2], ca = Math.cos(t), sa = Math.sin(t), cb = Math.cos(t * .7), sb = Math.sin(t * .7);
  const P = sp.v.map(([a, b, c]) => { const X = a * ca + c * sa, Z1 = -a * sa + c * ca, Y = b * cb - Z1 * sb, Z = b * sb + Z1 * cb, k = 3 / (3 + Z); return [cx + X * r * k, cy + Y * r * k, Z]; });
  x.strokeStyle = A(col, al); x.lineWidth = 1.6; x.beginPath(); sp.e.forEach(([i, j]) => { x.moveTo(P[i][0], P[i][1]); x.lineTo(P[j][0], P[j][1]); }); x.stroke();
  x.fillStyle = A('#ffffff', al); P.forEach(p => { x.beginPath(); x.arc(p[0], p[1], 2.5 + p[2], 0, 6.283); x.fill(); });
}
// 3D vonkenregen
function mkSparks() {
  const arr = [];
  return {
    burst(n, pw = 1, ox = 0, oy = 0) { for (let i = 0; i < n; i++) { const an = Math.random() * 6.283, v = (.25 + Math.random() * 1.1) * pw; arr.push({ x: ox, y: oy, z: 0, vx: Math.cos(an) * v, vy: Math.sin(an) * v - .25, vz: (Math.random() - .3) * v * 1.4, l: 1, d: .006 + Math.random() * .01, s: 1 + Math.random() * 2.6, w: Math.random() < .5 }); } },
    draw(x, W, H, col) {
      const cx = W / 2, cy = H / 2, m = Math.min(W, H); x.save(); x.globalCompositeOperation = 'lighter'; x.lineCap = 'round';
      for (let i = arr.length - 1; i >= 0; i--) {
        const s = arr[i]; s.l -= s.d; if (s.l <= 0) { arr.splice(i, 1); continue; }
        s.x += s.vx * .014; s.y += s.vy * .014; s.vy += .004; s.z += s.vz * .014;
        const k = 1 / Math.max(.25, 1 - s.z * .8), px = s.x - s.vx * .03, py = s.y - s.vy * .03, pz = s.z - s.vz * .03, k0 = 1 / Math.max(.25, 1 - pz * .8);
        x.strokeStyle = A(s.w ? '#ffffff' : col, s.l); x.lineWidth = s.s * k; x.beginPath(); x.moveTo(cx + px * m * k0, cy + py * m * k0); x.lineTo(cx + s.x * m * k, cy + s.y * m * k); x.stroke();
      }
      x.restore();
    }
  };
}

// 3D tunnelvloer + plafond met raster (zoals de spelerstunnel in FIFA)
function corridor(x, W, H, ph, a, col) {
  const cx = W / 2, cy = H / 2, n = 16; x.lineWidth = 1.2;
  for (let i = 0; i < n; i++) {
    const z = (i / n + ph) % 1, q = z ** 2.2; if (q < .004) continue; const w = W * .62 * q, dy = H * .5 * q;
    x.strokeStyle = A(col, Math.min(.5, q * 1.4) * a * .5); x.beginPath(); x.moveTo(cx - w, cy + dy); x.lineTo(cx + w, cy + dy); x.moveTo(cx - w, cy - dy); x.lineTo(cx + w, cy - dy); x.stroke();
  }
  x.strokeStyle = A(col, .1 * a); x.beginPath(); for (let k = -6; k <= 6; k++) { x.moveTo(cx, cy); x.lineTo(cx + k * W * .12, H); x.moveTo(cx, cy); x.lineTo(cx + k * W * .12, 0); } x.stroke();
}
// zachte mist die door de tunnel drijft
function fog(x, W, H, t, col, a) {
  x.save(); x.globalCompositeOperation = 'lighter';
  for (let k = 0; k < 6; k++) {
    const px = W * (.5 + .45 * Math.sin(t * .13 + k * 2.1)), py = H * (.5 + .35 * Math.cos(t * .17 + k * 1.7)), r = Math.max(W, H) * (.28 + .08 * Math.sin(t * .3 + k)), g = x.createRadialGradient(px, py, 0, px, py, r);
    g.addColorStop(0, A(col, .07 * a)); g.addColorStop(1, A(col, 0)); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
  }
  x.restore();
}
// schijnwerper boven de pack + lichtvlek op de vloer
function spot(x, W, H, a, col) {
  const cx = W / 2; x.save(); x.globalCompositeOperation = 'lighter';
  const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, A(col, .32 * a)); g.addColorStop(1, A(col, .02 * a)); x.fillStyle = g;
  x.beginPath(); x.moveTo(cx - W * .03, 0); x.lineTo(cx + W * .03, 0); x.lineTo(cx + W * .22, H * .86); x.lineTo(cx - W * .22, H * .86); x.closePath(); x.fill();
  x.translate(cx, H * .86); x.scale(1, .22); const r = W * .24, g2 = x.createRadialGradient(0, 0, 0, 0, 0, r); g2.addColorStop(0, A(col, .5 * a)); g2.addColorStop(1, A(col, 0)); x.fillStyle = g2; x.beginPath(); x.arc(0, 0, r, 0, 6.283); x.fill(); x.restore();
}
const clamp01 = v => Math.max(0, Math.min(1, v));
function countUp(el, to, ms = 900) { const t0 = performance.now(); (function f() { const p = Math.min(1, (performance.now() - t0) / ms); el.textContent = Math.round(to * (1 - (1 - p) ** 3)); if (p < 1 && el.isConnected) requestAnimationFrame(f); })(); }

async function play(c) {
  const tier = rar(c.grade), ac = RC[tier], st = VAR[c.theme % VAR.length][3], os = c.theme % 6, doc = docOf(c);
  const ov = h('div', 'sp-ov r' + tier), cv = document.createElement('canvas'), x = cv.getContext('2d'); let W = cv.width = innerWidth, H = cv.height = innerHeight;
  const resize = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; }; addEventListener('resize', resize);
  ov.style.setProperty('--ac', ac);
  const cam = h('div', 'sp-cam'), ghost = h('div', 'sp-L sp-ghost', c.vak), top = h('div', 'sp-L sp-top', 'NORMERING: ' + c.weging),
        tag = h('div', 'sp-L sp-tag', c.onderwerp), chip = h('div', 'sp-L sp-chip', 'DOCENT · ' + doc), flash = h('div', 'sp-flash'), stage = h('div', 'sp-stage'), texts = [ghost, top, tag, chip];
  cam.append(...texts, stage); ov.append(cv, h('div', 'sp-vig'), cam, h('div', 'sp-lb t'), h('div', 'sp-lb b'), flash); document.body.append(ov);
  ghost.style.fontSize = `min(13vw,170px,${(88 / (Math.max(c.vak.length, 6) * .75)).toFixed(1)}vw)`; fz(tag, fit(22, c.onderwerp, 24));
  ov.addEventListener('mousemove', e => { if (ov.classList.contains('fin')) return; ov.style.setProperty('--px', e.clientX / innerWidth - .5); ov.style.setProperty('--py', e.clientY / innerHeight - .5); });
  const animIdx = (S.club && S.club.anim != null) ? S.club.anim : (c.anim != null ? c.anim : (c.theme * 5 + 3)), sc = SC_ANIMS.create(animIdx, ac), rv = SC_ANIMS.createReveal(c.theme + animIdx, ac);
  let lastF = performance.now();
  const mu = music(c.theme, c.grade); let run = true, tun = 0, orb = 0, shake = 0, fa = 0, ph = 0, ready = false; const S0 = performance.now(), stars = mkStars(130), sk = mkSparks(), zs = Array.from({ length: 16 }, (_, i) => i / 16);
  const at = async ms => { while (performance.now() - S0 < ms) await sleep(30); };   // niet over te slaan
  const fl = () => { flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go'); fa = 1; }, on = n => { n.classList.remove('on'); void n.offsetWidth; n.classList.add('on'); };
  const shk = v => { shake = Math.max(shake, v); cam.classList.remove('shS', 'shL'); void cam.offsetWidth; cam.classList.add(v < .6 ? 'shS' : 'shL'); };
  const shards = () => { for (let i = 0; i < 22; i++) { const s = h('i', 'sp-sh'), w = 40 + Math.random() * 90; s.style.cssText = `width:${w}px;height:${w * (.6 + Math.random() * .8)}px;--x:${(Math.random() - .5) * 1500}px;--y:${(Math.random() - .5) * 1000}px;--z:${Math.random() * 700 - 100}px;--r:${(Math.random() - .5) * 1200}deg;clip-path:polygon(${Math.random() * 30}% ${Math.random() * 30}%,100% ${Math.random() * 40}%,${50 + Math.random() * 50}% 100%,0 ${60 + Math.random() * 40}%)`; cam.append(s); setTimeout(() => s.remove(), 1800); } };
  const face = () => { const f = h('div', 'face'); f.append(h('small', '', 'SOMTODAY'), fz(h('b', '', c.vak), fit(22, c.vak, 9)), h('small', '', 'PACK')); return f; };
  // de pack scheurt in twee helften met een lichtspleet ertussen
  const halves = () => { const t = h('div', 'sp-half t'), b = h('div', 'sp-half b'), tr = h('i', 'sp-tear'); t.append(face()); b.append(face()); stage.append(t, b, tr); setTimeout(() => [t, b, tr].forEach(n => n.remove()), 1700); };
  const tc = tier === 2 ? '#e8d890' : tier === 3 ? '#b8e8f4' : '#d2d2dc';
  // pack: staat in de schijnwerper, trilt steeds harder, barst open
  const pkw = h('div', 'sp-pkw'), pk = h('div', 'sp-pk3'), fc = h('div', 'face f'), bk = h('div', 'face bk');
  fc.append(h('small', '', 'SOMTODAY'), fz(h('b', '', c.vak), fit(22, c.vak, 9)), h('small', '', 'PACK')); fc.insertAdjacentHTML('beforeend', '<svg class="crk" viewBox="0 0 200 290"><polyline points="0,145 28,131 50,152 78,128 104,153 132,129 160,151 200,138"/></svg>');
  bk.append(h('small', '', 'ULTIMATE TEAM'), h('b', '', '?'), h('small', '', 'SOMTODAY')); pk.append(h('div', 'side l'), h('div', 'side r'), bk, fc); pkw.append(pk); stage.append(pkw);
  (function draw() {
    if (!run) return; const now = performance.now(), dt = Math.min(.1, (now - lastF) / 1000), e = (now - S0) / 1000, sp = .0010 + (Math.min(e, 19) / 19) ** 2.2 * .016, m0 = Math.min(W, H); ph += sp * 1.1; lastF = now;
    x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.fillStyle = '#050507'; x.fillRect(0, 0, W, H);
    const jx = (Math.random() - .5) * shake * 22, jy = (Math.random() - .5) * shake * 22; shake *= .93;
    if (pkw.isConnected) { const r = Math.max(0, (e - 1.5) / 1.9), a = r * r * 9; pkw.style.translate = `${((Math.random() - .5) * a).toFixed(1)}px ${((Math.random() - .5) * a).toFixed(1)}px`; pk.style.setProperty('--hot', Math.min(1, r).toFixed(3)); }
    x.save(); x.translate(W / 2 + jx, H / 2 + jy); x.rotate(tun ? Math.sin(e * .45) * .06 : 0); x.translate(-W / 2, -H / 2);   // camera-roll
    if (!tun && pkw.isConnected) spot(x, W, H, Math.min(1, e / 1.2) * .9, '#ffffff');
    streaks(x, W, H, stars, sp * 1.5, Math.min(1, e / 2) * (tun ? .12 : .35), tun ? tc : ac);
    if (tun) { const tt = (now - tun) / 1000; sc.draw(x, W, H, tt, dt, Math.min(1, tt / 1.5)); }
    if (orb) { const ot = (now - orb) / 1000, oa = Math.min(1, ot / 1.2); beams(x, W, H, ot, ac, oa * .8, 16); orbDraw(os, x, W, H, ot, ac); rv.draw(x, W, H, ot, dt, oa, 3); fog(x, W, H, ot + 20, ac, oa); wire(x, W / 2, H / 2, m0 * .36, ot * .8, ac, oa * .55, os); wire(x, W / 2, H / 2, m0 * .52, -ot * .5, '#ffffff', oa * .2, os + 1); if (tier >= 1 && Math.random() < .12) sk.burst(2, .35); }
    sk.draw(x, W, H, ac); x.restore();
    fa *= .94; flare(x, W, H, Math.max(fa, (tun ? .25 * Math.min(1, e / 19) : 0) + (orb ? .04 : 0)), ac); requestAnimationFrame(draw);
  })();
  await at(3400); fl(); shk(1); mu.hit(false); mu.whoosh(); stage.innerHTML = ''; halves(); tun = performance.now(); cam.classList.add('dolly'); sk.burst(180, 1.3); shards();
  await at(4600); mu.whoosh(); await at(6200); on(ghost); mu.whoosh(); await at(9800); on(top); mu.hit(false); mu.whoosh(); shk(.4);
  await at(11500); if (doc) { on(chip); mu.whoosh(); }
  await at(13300); on(tag); mu.hit(false); mu.whoosh(); shk(.4); await at(16300); fl(); mu.hit(false); shk(.7);
  await at(19400); texts.forEach(n => { n.style.transition = 'opacity .8s'; n.style.animation = 'none'; n.style.opacity = 0; }); tun = 0; cam.classList.remove('dolly'); mu.hit(true); shk(1);
  await at(20400);
  const big = h('div', 'sp-big', '0,0'); stage.append(h('div', 'sp-t', doc ? 'DOCENT ' + doc : ' '), big, h('div', 'sp-t', c.vak));
  const isL = GRADE_L.test(c.grade), T0 = performance.now(), D = isL ? 4800 : 4000; let last = 0, nxt = 0, li = 0;
  for (;;) {   // cijfers tellen op, O/V/G wisselen tot ze stoppen
    const now = performance.now(), p = Math.min(1, (now - T0) / D);
    if (isL) { if (now >= nxt) { li = (li + 1) % 3; big.textContent = 'OVG'[li]; nxt = now + 70 + p ** 2 * 520; mu.tick(p); shk(.15); } }
    else { big.textContent = (num(c.grade) * (1 - (1 - p) ** 3)).toFixed(1).replace('.', ','); if (now - last > 60 + p * 200) { last = now; mu.tick(p); shk(.1 + p * .3); } }
    if (p >= 1) break; await at(now - S0 + 30);
  }
  // het cijfer slaat in: camera-punch, shockwave, sparks, rarity-label, publiek
  big.textContent = c.grade; big.classList.add('land'); orb = performance.now(); fl(); shk(1); mu.hit(true); mu.roar(tier); sk.burst(tier >= 2 ? 260 : 150, 1.4);
  cam.classList.add('punch'); setTimeout(() => cam.classList.remove('punch'), 900);
  const rl = h('div', 'sp-L sp-rar', RN[tier]); cam.append(rl); on(rl); texts.push(rl);
  for (let i = 0; i < 3; i++) { const r = h('i', 'sp-ring'); r.style.animationDelay = i * .18 + 's'; cam.append(r); setTimeout(() => r.remove(), 2400); }
  await at(performance.now() - S0 + 3800); fl(); sk.burst(80, .9);
  texts.forEach(n => n.remove()); stage.innerHTML = ''; ov.classList.add('fin');
  const fin = h('div', 'sp-fin'), side = h('div', 'sp-side'), btn = h('button', '', 'SLUITEN'), row = (k, v, i) => { const r = h('div', 'row'), vv = h('span', 'v', v); r.style.animationDelay = .5 + i * .12 + 's'; r.append(h('span', 'k', k), vv); return r; };
  side.append(h('h4', '', 'OVERZICHT'), h('div', 'pill', RN[tier]), row('Vak', c.vak, 0), row('Docent', doc || '-', 1), row('Toets', c.onderwerp, 2), row('Weging', c.weging, 3), row('Punten/min', ppm(c), 4), btn); fin.append(cardEl(c), side); stage.append(fin);
  mu.quiet(); mu.finale(); const stopT = setTimeout(() => mu.stop(), 6500); ready = true;
  let closed = 0; const key = e => { if (e.key === 'Escape' && ready) close(); }, close = () => { if (closed) return; closed = 1; run = false; mu.stop(); clearTimeout(stopT); removeEventListener('resize', resize); removeEventListener('keydown', key); ov.remove(); shield(); };
  addEventListener('keydown', key); btn.onclick = ev => { ev.stopPropagation(); ev.preventDefault(); close(); }; ov.onclick = e => { if (ready && (e.target === ov || e.target === cam)) { e.stopPropagation(); close(); } };
}

// ---------- SOMtoday uitlezen ----------
const FULL = /^(nederlands|engels|duits|frans|spaans|latijn|grieks|wiskunde|natuurkunde|scheikunde|biologie|aardrijkskunde|geschiedenis|economie|bedrijfseconomie|maatschappijleer|maatschappijwetenschappen|lichamelijke opvoeding|informatica|kunst|muziek|tekenen|handvaardigheid|techniek|levensbeschouwing|filosofie|mentor|culturele|beeldende|drama|godsdienst|loopbaan|nask|natuurwetenschappen|science)/i;
const ABBR = /^(netl|nl|entl|en|dutl|du|fatl|fa|wisa|wisb|wisc|wisd|wi|wis|na|nat|sk|bi|bio|ak|gs|ec|be|ml|maw|lo|in|inf|kubv|ckv|mu|te|ha|la|gr|sp|lob|lb|fi|tn|ne|ned)$/i;
const isVak = s => s.length < 40 && (FULL.test(s) || ABBR.test(s));
const DATE_IN = /(\d{1,2}[-\/.]\d{1,2}(?:[-\/.]\d{2,4})?|\d{1,2}\s(?:jan|feb|mrt|apr|mei|jun|jul|aug|sep|okt|nov|dec)[a-z]*\.?(?:\s\d{4})?)/i;
const isDate = s => (DATE_IN.test(s) && s.replace(DATE_IN, '').trim().length < 3) || /^(vandaag|gisteren|eergisteren)/i.test(s);
const isTeacher = s => !isVak(s) && (/^([A-Z]\.\s?)+[A-Za-z' -]+$/.test(s) || /^[A-Z]{2,4}$/.test(s) || /^(dhr|mevr|mw|dr)\.?\s/i.test(s) || /^([A-Z][\w'-]+\s){1,3}(van |de |der |den )?[A-Z][\w'-]+$/.test(s));
const NOISE = /^(laatste|recente|nieuwste|cijfers|resultaten|beoordelingen|open pack|vak ?gemiddelde|gemiddelde)/i, WEG = /(\bweging\b|\d\s?x\b)/i;
const countG = n => [...n.querySelectorAll('*')].filter(isGradeEl).length;
function findW(t) { const m = t.match(/weging\D{0,4}(\d+(?:[,.]\d+)?)/i) || t.match(/(\d+(?:[,.]\d+)?)\s?x\b/i) || t.match(/\bx\s?(\d+(?:[,.]\d+)?)\b/i) || t.match(/weegt\D{0,4}(\d+(?:[,.]\d+)?)/i); return m ? m[1].replace(',', '.') + 'x' : null; }
function info(e) {
  const grade = own(e); let row = e;
  for (let i = 0; i < 8 && row.parentElement && row.parentElement !== document.body && countG(row.parentElement) <= 1; i++) row = row.parentElement;
  const parts = [], w = document.createTreeWalker(row, NodeFilter.SHOW_TEXT);
  for (let n; (n = w.nextNode());) { const t = n.textContent.trim().replace(/\s+/g, ' '); if (t && t !== grade && !n.parentElement.closest('.sc-open,.sc-re')) parts.push(t); }
  row.querySelectorAll('[title],[aria-label]').forEach(a => ['title', 'aria-label'].forEach(k => { const t = (a.getAttribute(k) || '').trim(); if (t && t.length < 120) parts.push(t); }));
  let weging = null, anc = row; for (let i = 0; i < 4 && anc && !weging; i++, anc = anc.parentElement) { const t = anc.textContent; if (t.length < 900) weging = findW(parts.join(' | ')) || findW(t.replace(/Open pack/g, '')); }
  const okT = t => t && t.length > 1 && t.length < 120 && !GRADE.test(t) && !isDate(t) && !WEG.test(t) && !NOISE.test(t);
  const vak = parts.find(t => okT(t) && isVak(t)) || parts.find(t => okT(t) && !isTeacher(t)) || 'Vak'; let onderwerp = null;
  // onderwerp = de tekst naast de datum (bijv. "abcd schrijf toets")
  for (const t of parts) { if (GRADE.test(t) || !DATE_IN.test(t)) continue; const r = t.replace(DATE_IN, '').replace(/^[\s\-–·,:|()]+|[\s\-–·,:|()]+$/g, ''); if (okT(r) && r !== vak && !isVak(r) && !isTeacher(r)) { onderwerp = r; break; } }
  if (!onderwerp) { const di = parts.findIndex(t => isDate(t)); if (di >= 0) onderwerp = [1, -1, 2, -2].map(k => parts[di + k]).find(t => okT(t) && t !== vak && !isVak(t) && !isTeacher(t)) || null; }
  const docent = parts.find(t => okT(t) && t !== vak && t !== onderwerp && isTeacher(t)) || '';
  if (!onderwerp) onderwerp = parts.find(t => okT(t) && t !== vak && t !== docent && !isVak(t)) || 'Toets';
  return { grade, vak, onderwerp, docent, weging: weging || '1x' };
}
// alleen onder "Laatste resultaten / cijfers": niet bij cijferoverzicht of vakgemiddelden
const LAATSTE = /^(laatste|recente?|nieuwste|nieuwe).{0,20}(resultaten|resultaat|cijfers|cijfer|beoordelingen)/i, ANDERS = /^(vak ?gemiddelde[n]?|gemiddelde[n]?)$/i;
const REG = {};
function findCard(i) {
  const id = norm(i.vak) + '|' + norm(i.onderwerp); if (S.cards[id]) return [id, S.cards[id]];
  const cv = canon(i.vak), no = norm(i.onderwerp);
  for (const [k, c] of Object.entries(S.cards)) if (canon(c.vak) === cv && c.grade === i.grade && (norm(c.onderwerp).includes(no) || no.includes(norm(c.onderwerp)))) return [k, c];
  return [id, null];
}
function handle0(e) {
  e.dataset.sp = 1; const i = info(e); let [id, c] = findCard(i);
  if (!c) c = S.cards[id] = { ...i, theme: Math.floor(Math.random() * VAR.length), opened: false };
  else if (c.grade !== i.grade) Object.assign(c, i, { opened: false });
  else { if (i.weging !== '1x') c.weging = i.weging; if (!c.docent && i.docent) c.docent = i.docent; }
  const re = el => { const b = h('button', 'sc-re'); b.innerHTML = ICON; b.title = 'Replay'; b.onclick = ev => { ev.stopPropagation(); ev.preventDefault(); play(c); }; el.after(b); };
  if (c.opened) return re(e);
  e.style.display = 'none'; const b = h('button', 'sc-open', 'Open pack'); e.before(b); (REG[id] = REG[id] || []).push({ e, b });
  b.onclick = async ev => {
    ev.stopPropagation(); ev.preventDefault();
    if (c.opened) { b.remove(); e.style.display = ''; return re(e); }
    sfx(300, .3, .06, 'sawtooth', 1000); c.opened = true; save();
    (REG[id] || []).forEach(r => { r.b.remove(); if (r.e !== e) { r.e.style.display = ''; re(r.e); } }); REG[id] = [];
    await play(c); e.style.display = ''; re(e);
  };
}
const ALIAS = { nederlands: ['netl', 'ne', 'nl', 'ned'], engels: ['entl', 'en'], duits: ['dutl', 'du'], frans: ['fatl', 'fa'], wiskunde: ['wi', 'wis', 'wisa', 'wisb', 'wisc', 'wisd'], natuurkunde: ['na', 'nat'], scheikunde: ['sk'], biologie: ['bi', 'bio'], aardrijkskunde: ['ak'], geschiedenis: ['gs'], economie: ['ec'], bedrijfseconomie: ['be'], maatschappijleer: ['ml', 'maw'], 'lichamelijke opvoeding': ['lo'], informatica: ['in', 'inf'], kunst: ['kubv', 'ckv'], muziek: ['mu'], tekenen: ['te'], handvaardigheid: ['ha'], latijn: ['la'], grieks: ['gr'], spaans: ['sp'], levensbeschouwing: ['lb'], filosofie: ['fi'], techniek: ['tn'], loopbaan: ['lob'] };
const canon = v => { const t = String(v).toLowerCase().trim(); for (const [k, a] of Object.entries(ALIAS)) if (t.startsWith(k) || a.includes(t)) return k; return t; };
// docent-afkorting uit het rooster: per vak de eerstvolgende les (volgorde op de pagina)
const TIME = /^\d{1,2}[:.]\d{2}(\s?[-–]\s?\d{1,2}[:.]\d{2})?$/;
const textsOf = b => { const r = [], w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT); for (let n; (n = w.nextNode()) && r.length < 16;) { const t = n.textContent.trim().replace(/\s+/g, ' '); if (t) r.push(t); } return r; };
const OVERLAY = /(modal|dialog|popup|popover|dropdown|tooltip|cdk-overlay|instelling)/i;
// grade-voorbeelden in instellingen/dialogen ("onvoldoendes en voldoendes kleur geven") krijgen nooit een pack
function inSettings(e) {
  for (let n = e, i = 0; n && n !== document.body; n = n.parentElement, i++) {
    if (n.tagName === 'DIALOG' || /^(dialog|alertdialog|menu|tooltip)$/.test(n.getAttribute('role') || '') || n.getAttribute('aria-modal') === 'true' || OVERLAY.test(cls(n))) return true;
    if (i < 7 && n.textContent.length < 900 && /kleur geven|instellingen|onvoldoendes|voldoendes/i.test(n.textContent)) return true;
  } return false;
}
const BLOCKW = /^(les|uur|uit|geen|toets|maa|din|woe|don|vri|zat|zon|van|tot|nu|huiswerk|lokaal|week)$/i;
function roster(anchors) {
  const seen = new Set();
  anchors.forEach(e => { let b = e;
    for (let i = 0; i < 6 && b && b !== document.body; i++, b = b.parentElement) {
      const t = textsOf(b); if (t.length > 14) break;
      const bits = t.flatMap(s => s.split(/\s+[-–·|•]\s+|\s*[|•·]\s*/)).map(s => s.trim()).filter(Boolean);
      const vak = bits.find(s => isVak(s) && !TIME.test(s)); if (!vak) continue; if (/vervallen|uitval|cancel/i.test(cls(b))) break;
      // de docent is altijd 3 letters (bijv. "abc") en staat bij het vak
      let code = bits.find(s => s !== vak && /^[A-Za-z]{3}$/.test(s) && !isVak(s) && !NOISE.test(s) && !BLOCKW.test(s));
      if (!code) for (const a of b.querySelectorAll('[title],[aria-label]')) { const mm = ((a.getAttribute('title') || '') + ' ' + (a.getAttribute('aria-label') || '')).match(/docent\W+([A-Za-z]{3})\b/i); if (mm) { code = mm[1]; break; } }
      const k = canon(vak); if (code) { if (!seen.has(k)) { seen.add(k); S.rooster[k] = code.toUpperCase(); } break; }
    } });
}
function handle(e) { try { handle0(e); } catch (err) { e.style.display = ''; console.error('SOMtoday Packs:', err); } }
const headLike = n => /^H[1-6]$/.test(n.tagName) || n.getAttribute('role') === 'heading' || /title|header|kop|heading/i.test(cls(n));
function decorate() {
  const onPage = /^\/cijfers\/?$/i.test(location.pathname), onRoo = /^\/rooster/i.test(location.pathname); let active = onPage, lvl = 0; const list = [], times = [];
  if (!onPage && document.querySelector('.sc-open,.sc-re')) { document.querySelectorAll('.sc-open,.sc-re').forEach(b => b.remove()); document.querySelectorAll('[data-sp]').forEach(e => { e.style.display = ''; delete e.dataset.sp; }); Object.keys(REG).forEach(k => delete REG[k]); }
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, { acceptNode: n => ((n.classList && (n.classList.contains('sc-m') || n.classList.contains('sp-ov') || n.classList.contains('sc-toasts'))) || n.tagName === 'SCRIPT' || n.tagName === 'STYLE' ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
  for (let e; (e = w.nextNode());) {
    const t = own(e); if (!t) continue; if (TIME.test(t) || (onRoo && isVak(t))) times.push(e);
    if (active && !e.dataset.sp && isGradeEl(e)) { if (!inSettings(e)) list.push(e); continue; }
    if (onPage && LAATSTE.test(t)) { active = true; const m = e.tagName.match(/^H([1-6])$/); lvl = m ? +m[1] : 9; continue; }
    if (active && (/^H[1-6]$/.test(e.tagName) || e.getAttribute('role') === 'heading') && t.length < 40) { const m = e.tagName.match(/^H([1-6])$/); if (ANDERS.test(t) || (m && +m[1] <= lvl)) active = false; }
  }
  list.forEach(handle); roster(times); save();
}
// Ctrl+Shift+H: kopieert de HTML rond "Laatste resultaten" naar je klembord (om te plakken in de chat)
document.addEventListener('keydown', async e => {
  if (!(e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'h')) return;
  let el = [...document.querySelectorAll('*')].find(n => isGradeEl(n)); for (let i = 0; i < 6 && el && el.parentElement && el.parentElement !== document.body; i++) el = el.parentElement;
  const heads = [...document.querySelectorAll('h1,h2,h3,h4,[role=heading]')].map(n => n.tagName + ': ' + n.textContent.trim().slice(0, 40)).join('\n');
  const html = el ? el.outerHTML.replace(/<svg[\s\S]*?<\/svg>/g, '<svg/>').replace(/\s(style|d|viewBox|fill|stroke)="[^"]*"/g, '').slice(0, 7000) : '(geen cijfer gevonden)';
  try { await navigator.clipboard.writeText('PAD: ' + location.pathname + '\nKOPPEN:\n' + heads + '\n\nHTML:\n' + html); } catch (_) {}
  const t = h('div', 'sc-btn p', 'HTML gekopieerd: plak het in de chat'); t.style.cssText = 'position:fixed;left:50%;bottom:70px;transform:translateX(-50%);z-index:99999;display:flex;align-items:center'; document.body.append(t); setTimeout(() => t.remove(), 3500);
});

// ---------- club ----------
const FORM = { '4-3-3': [3, 3, 4, 1], '4-4-2': [2, 4, 4, 1], '3-5-2': [2, 5, 3, 1] };
const RANKS = ['Amateur', 'Talent', 'Eerste elftal', 'Profclub', 'Topclub', 'Wereldclub', 'Legende'], rank = l => RANKS[Math.min(RANKS.length - 1, Math.floor((l - 1) / 2))];
const tierOf = l => (l >= 9 ? 3 : l >= 6 ? 2 : l >= 3 ? 1 : 0);
const NS = 'http://www.w3.org/2000/svg';
const openedCards = () => Object.values(S.cards).filter(c => c.opened);
// posities in het veld + FIFA-achtige links tussen buren
const POS = fm => { const p = []; FORM[fm].forEach((n, r) => { for (let j = 0; j < n; j++) p.push({ r, j, x: (j + 1) / (n + 1), y: [17, 40, 64, 87][r] }); }); return p; };
const LINKS = fm => { const P = POS(fm), L = []; P.forEach((a, i) => P.forEach((b, k) => { if (k > i && ((a.r === b.r && b.j === a.j + 1) || (b.r === a.r + 1 && Math.abs(a.x - b.x) <= .21))) L.push([i, k]); })); return L; };
const strong = (fm, a, b) => { const ca = S.cards[S.club.lineup[a]], cb = S.cards[S.club.lineup[b]]; return !!(ca && cb && docOf(ca) && docOf(ca) === docOf(cb)); };
function chemOf() { const fm = S.club.formation || '4-3-3', per = Array(11).fill(0); let n = 0; LINKS(fm).forEach(([a, b]) => { if (strong(fm, a, b)) { n++; per[a]++; per[b]++; } }); return { n, per }; }
const chemMult = () => 1 + Math.min(.5, chemOf().n * .04);
const ovr = () => Math.round(S.club.lineup.reduce((a, id) => a + (S.cards[id] ? num(S.cards[id].grade) : 0), 0) / 11 * 10);
// dagelijkse beloning
const claimLeft = () => Math.max(0, (S.club.lastClaim || 0) + 20 * 36e5 - Date.now());
const nextStreak = () => (S.club.lastClaim && Date.now() - S.club.lastClaim < 48 * 36e5 ? Math.min(7, (S.club.streak || 0) + 1) : 1);
const claimAmt = () => Math.round((60 + total() * 15) * (1 + .25 * (nextStreak() - 1)));
function claimDo() { const r = claimAmt(); S.club.streak = nextStreak(); S.club.points += r; S.club.lastClaim = Date.now(); save(); return r; }
const fmtT = ms => { const mm = Math.ceil(ms / 6e4); return mm >= 60 ? Math.floor(mm / 60) + 'u ' + (mm % 60) + 'm' : mm + 'm'; };
// prestaties
const ACH = [
  ['first', 'Eerste pack', 'Open je eerste pack', () => openedCards().length >= 1, 50],
  ['five', 'Pack-verslaafd', 'Open 5 packs', () => openedCards().length >= 5, 150],
  ['twenty', 'Verzamelaar', 'Open 20 packs', () => openedCards().length >= 20, 500],
  ['gold', 'Goud!', 'Haal een gouden kaart (7,5+)', () => openedCards().some(c => rar(c.grade) >= 2), 100],
  ['icon', 'ICON', 'Haal een ICON-kaart (9+)', () => openedCards().some(c => rar(c.grade) === 3), 300],
  ['ten', 'Perfect', 'Haal een 10', () => openedCards().some(c => num(c.grade) >= 10), 500],
  ['full', 'Volle bak', 'Vul alle 11 plekken', () => S.club.lineup.every(Boolean), 200],
  ['chem', 'Teamchemie', 'Maak 5 chemie-links', () => chemOf().n >= 5, 250],
  ['lvl3', 'Opkomende club', 'Bereik level 3', () => S.club.level >= 3, 150],
  ['lvl6', 'Topclub', 'Bereik level 6', () => S.club.level >= 6, 600],
  ['ovr70', 'Sterrenteam', 'Team OVR 70 of hoger', () => ovr() >= 70, 300],
  ['docs', 'Docentenfan', 'Kaarten van 3 verschillende docenten', () => new Set(openedCards().map(docOf).filter(Boolean)).size >= 3, 200],
  ['streak3', 'Trouwe fan', '3 dagen streak', () => (S.club.streak || 0) >= 3, 300],
  ['earn1k', 'Rijk', 'Verdien 1000 punten', () => (S.club.earned || 0) >= 1000, 200]
];
function toast(t, s) {
  let box = document.querySelector('.sc-toasts'); if (!box) { box = h('div', 'sc-toasts'); document.body.append(box); }
  const d = h('div', 'sc-toast'); d.append(h('b', '', t), h('span', '', s || '')); box.append(d); sfx(880, .2, .05, 'triangle', 1320);
  setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 500); }, 3800);
}
function checkAch() {
  if (!S.club) return false; S.club.ach = S.club.ach || {}; let ch = false;
  const got = []; ACH.forEach(([id, t, , f, r]) => { if (!S.club.ach[id] && f()) { S.club.ach[id] = Date.now(); S.club.points += r; ch = true; got.push([t, r]); } });
  if (got.length > 3) toast('🏆 ' + got.length + ' prestaties behaald', '+' + got.reduce((a, g) => a + g[1], 0) + ' punten · bekijk tab Prestaties'); else got.forEach(([t, r]) => toast('🏆 ' + t, '+' + r + ' punten'));
  if (ch) save(); return ch;
}
function confetti(par, n = 60) {
  const w = h('div', 'sc-cfw'), cols = ['#ffd400', '#7fe3ff', '#ff5ea8', '#6dff8f', '#ffffff'];
  for (let i = 0; i < n; i++) { const p = h('i'); p.style.cssText = `left:${45 + Math.random() * 10}%;--x:${(Math.random() - .5) * 1100}px;--y:${-260 - Math.random() * 380}px;--r:${Math.random() * 1440}deg;background:${cols[i % 5]};animation-delay:${Math.random() * .2}s;animation-duration:${1.5 + Math.random()}s`; w.append(p); }
  par.append(w); setTimeout(() => w.remove(), 3000);
}
const BOTS = ['FC Pauze', 'Mentor United', 'Real Kantine', 'Havo Galácticos', 'Atlético Bieb', 'VV Lokaal 204', 'Inhaal Rovers', 'Gym Gladiators', 'Spijbel City', 'Toets Titans'];
const botRows = () => { const mins = (Date.now() - (S.club.since || Date.now())) / 6e4; return BOTS.map((n, i) => { const pp = 18 + (i * 37) % 70; return { name: n, level: 1 + (i * 3 + Math.floor(mins / 600)) % 8, points: Math.floor(400 + i * 430 + mins * pp * .6), ppm: pp }; }); };
let FAB;

// muziek voor de teampresentatie: C-majeur (C-Am-F-G), dezelfde noten als de kaart-geluidjes en het eindakkoord
function presMusic() {
  const ctx = new AudioContext(), m = ctx.createGain(), comp = ctx.createDynamicsCompressor(); m.gain.value = .55; m.connect(comp).connect(ctx.destination);
  const nb = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate), nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const tone = (f, t, d, type, v) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.value = f; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(v, t + .02); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(m); o.start(t); o.stop(t + d + .05); };
  const kick = (t, v = .7) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + .14); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + .25); o.connect(g).connect(m); o.start(t); o.stop(t + .27); };
  const hat = (t, v) => { const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = nb; f.type = 'highpass'; f.frequency.value = 7500; g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + .05); s.connect(f).connect(g).connect(m); s.start(t); s.stop(t + .06); };
  const ROOT = [130.81, 110, 87.31, 98], CH = [[261.63, 329.63, 392], [220, 261.63, 329.63], [174.61, 220, 261.63], [196, 246.94, 293.66]], ARP = [[523.25, 659.25, 783.99, 1046.5], [440, 523.25, 659.25, 880], [349.23, 440, 523.25, 698.46], [392, 493.88, 587.33, 783.99]], PAT = [0, 1, 2, 3, 2, 1, 2, 3];
  const sp = 60 / 112 / 4; let next = ctx.currentTime + .1, step = 0, alive = true;
  const iv = setInterval(() => { while (alive && next < ctx.currentTime + .3) {
    const bar = ((step / 16) | 0) % 4, st = step % 16, build = Math.min(1, step / 48);
    if (st % 4 === 0) kick(next, .55 + .2 * build); if (st % 2 === 1 && step > 16) hat(next, .05 + .04 * build);
    if (st % 8 === 0) tone(ROOT[bar], next, sp * 7, 'triangle', .22); if (st === 0) CH[bar].forEach(f => tone(f, next, sp * 15, 'sine', .05 + .02 * build));
    if (step > 8) tone(ARP[bar][PAT[st % 8]], next, sp * 1.7, 'triangle', .03 + .02 * build); next += sp; step++; } }, 60);
  return {
    finale() { const t = ctx.currentTime; [523.25, 659.25, 783.99, 1046.5].forEach((f, k) => { tone(f, t + k * .09, 3.2, 'triangle', .09); tone(f / 2, t + k * .09, 3.2, 'sine', .06); }); kick(t, 1); },
    stop() { if (!alive) return; alive = false; clearInterval(iv); try { m.gain.linearRampToValueAtTime(0, ctx.currentTime + .5); } catch (e) {} setTimeout(() => { try { ctx.close(); } catch (e) {} }, 4000); }
  };
}
// teampresentatie: de spelers vallen in 3D het veld in, daarna de team-OVR
function present(m) {
  const fm = S.club.formation || '4-3-3', P = POS(fm), o = h('div', 'sc-pres'), cv = document.createElement('canvas'), x = cv.getContext('2d'), sk = mkSparks(), stars = mkStars(90), gold = '#ffd400', pit = h('div', 'pres-pitch'), bgs = SC_ANIMS.create((Math.random() * SC_ANIMS.count) | 0, gold);
  const W = cv.width = innerWidth, H = cv.height = innerHeight, m0 = Math.min(W, H), T0 = performance.now(); let run = true;
  const mu = presMusic(); let stopT = 0; const key = e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } }, close = () => { if (!run) return; run = false; clearTimeout(stopT); mu.stop(); removeEventListener('keydown', key, true); o.remove(); shield(); };
  addEventListener('keydown', key, true);
  let lf = performance.now(), px0 = 0, py0 = 0, px1 = 0, py1 = 0;
  o.addEventListener('mousemove', e => { px1 = e.clientX / innerWidth - .5; py1 = e.clientY / innerHeight - .5; });
  (function draw() { if (!run) return; const nw = performance.now(), dt = Math.min(.1, (nw - lf) / 1000); lf = nw; x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.fillStyle = '#030304'; x.fillRect(0, 0, W, H); const t = (nw - T0) / 1000; bgs.draw(x, W, H, t, dt, Math.min(1, t), 2.6); sk.draw(x, W, H, '#ffffff');
    px0 += (px1 - px0) * .07; py0 += (py1 - py0) * .07; const fin = clamp01((t - 8) / 3), ang = Math.sin(t * .32) * (62 - fin * 40) + px0 * 18, tl = 56 + Math.sin(t * .21 + 1) * 8 - fin * 8 + py0 * -10; o.style.setProperty('--ang', ang.toFixed(2) + 'deg'); o.style.setProperty('--tilt', tl.toFixed(2) + 'deg'); o.style.setProperty('--zoom', (1 + Math.sin(t * .4) * .06 + fin * .06).toFixed(3)); requestAnimationFrame(draw); })();
  const turf = h('div', 'pres-turf'); ['o', 'h', 'c'].forEach(c => turf.append(h('div', 'pl ' + c))); pit.append(turf); o.append(cv, pit);
  const xb = h('button', 'sc-btn sm pres-x', 'Sluiten'); xb.onclick = close; o.append(xb); m.append(o);
  const order = P.map((q, i) => i).filter(i => S.cards[S.club.lineup[i]]).sort((a, b) => P[b].r - P[a].r || P[a].j - P[b].j);
  (async () => {
    await sleep(600);
    for (const idx of order) {
      if (!o.isConnected) return; const q = P[idx], c = S.cards[S.club.lineup[idx]], sl = h('div', 'pres-slot sp-rar-' + rar(c.grade)), cd = cardEl(c); sl.style.left = q.x * 100 + '%'; sl.style.top = q.y + '%'; cd.classList.add('pres-card'); sl.append(cd); pit.append(sl);
      const t = rar(c.grade), nf = [261.63, 329.63, 392, 523.25][t]; sfx(nf, .35, .05, 'triangle', nf * 2); sfx(nf * 2, .5, .03, 'sine'); const r = sl.getBoundingClientRect(); sk.burst(t >= 2 ? 70 : 35, .8, (r.left - W / 2) / m0, (r.top - H / 2) / m0); await sleep(520);
    }
    await sleep(500); if (!o.isConnected) return;
    const ovv = h('div', 'pres-ovr'), nb = h('b', '', '0'); ovv.append(h('small', '', S.club.name.toUpperCase()), nb, h('span', '', 'TEAM OVR'), h('em', '', `${chemOf().n} chemie-links · ${total()} punten/min`)); o.append(ovv);
    countUp(nb, ovr(), 1400); sk.burst(220, 1.4); mu.finale(); stopT = setTimeout(() => mu.stop(), 7000); [523, 659, 784, 1047].forEach((f, k) => setTimeout(() => sfx(f, .3, .05, 'triangle'), k * 90));
  })();
}

function club() {
  sfx(400, .3, .05, 'triangle', 900);
  const m = h('div', 'sc-m'), p = h('div', 'sc-p'), glow = h('div', 'sc-glow'); m.append(glow, p); document.body.append(m);
  let cclosed = 0, tab = 0, pick = -1, lastP = -1, filt = -1, fresh = true, dropAll = false, dropIdx = -1;
  const onKey = e => { if (e.key === 'Escape' && !m.querySelector('.sc-pres')) close(); }, close = () => { if (cclosed) return; cclosed = 1; clearInterval(iv); removeEventListener('keydown', onKey); m.remove(); shield(); };
  addEventListener('keydown', onKey); m.onclick = e => { if (e.target === m) close(); };
  let pdx = 0, pdy = 0, cdx = 0, cdy = 0, praf = 0; const pstep = () => { cdx += (pdx - cdx) * .08; cdy += (pdy - cdy) * .08; p.style.setProperty('--rx', -cdy * 8 + 'deg'); p.style.setProperty('--ry', cdx * 12 + 'deg'); p.style.setProperty('--px', cdx * 2); p.style.setProperty('--py', cdy * 2); glow.style.transform = `translate(${cdx * -90}px,${cdy * -90}px)`; praf = m.isConnected ? requestAnimationFrame(pstep) : 0; };
  m.addEventListener('mousemove', e => { pdx = e.clientX / innerWidth - .5; pdy = e.clientY / innerHeight - .5; if (!praf) praf = requestAnimationFrame(pstep); });
  const iv = setInterval(() => {
    if (!S.club) return; accrue(); checkAch(); const e = p.querySelector('.pts'), f = Math.floor(S.club.points);
    if (e && f !== lastP) { e.textContent = f; if (lastP >= 0) { e.classList.remove('bump'); void e.offsetWidth; e.classList.add('bump'); } lastP = f; }
    const b = p.querySelector('.bar i'); if (b) b.style.width = Math.min(100, S.club.points / upCost() * 100) + '%';
    const d = p.querySelector('.dly'); if (d) { const l = claimLeft(); if (l <= 0 && d.disabled) render(); else if (l > 0) d.textContent = 'Beloning over ' + fmtT(l); }
  }, 500);
  const banner = t => { const b = h('div', 'sc-lvl', t); m.append(b); setTimeout(() => b.remove(), 2200); };
  const header = () => {
    const hd = h('div', 'sc-h'), xb = h('button', 'x', '×'), t = h('div', 'sc-ht'); xb.onclick = close;
    hd.append(h('div', 'sc-crest t' + (S.club ? tierOf(S.club.level) : 1), S.club ? S.club.name[0].toUpperCase() : '⚽'));
    t.append(h('b', '', S.club ? S.club.name : 'Mijn kaarten')); if (S.club) t.append(h('small', '', rank(S.club.level).toUpperCase())); hd.append(t);
    if (S.club) hd.append(h('span', 'ovr-chip', 'OVR ' + ovr()), h('span', 'lv', 'LEVEL ' + S.club.level)); hd.append(xb); return hd;
  };
  const render = () => {
    p.innerHTML = '';
    if (!S.club) {
      const b = h('div', 'sc-b sc-mid'), inp = h('input', 'sc-in'), go = h('button', 'sc-btn p', 'Club aanmaken'), err = h('div', 'sc-err'), cr = h('div', 'sc-crest big t1', '⚽'); inp.placeholder = 'Naam van je club'; inp.maxLength = 16;
      inp.oninput = () => { const v = inp.value.trim(); cr.textContent = v ? v[0].toUpperCase() : '⚽'; };
      b.append(cr, h('h2', '', 'Maak je club'), h('div', 'sc-mut', 'Kies een naam (3-16 tekens, geen scheldwoorden).'), inp, go, err);
      go.onclick = () => { const n = inp.value.trim(); if (n.length < 3) return (err.textContent = 'Minstens 3 tekens.'); if (!cleanName(n)) return (err.textContent = 'Deze naam is niet toegestaan.'); S.club = { name: n, level: 1, points: 0, earned: 0, since: Date.now(), last: Date.now(), lineup: Array(11).fill(null), formation: '4-3-3', ach: {}, streak: 0, lastClaim: 0 }; save(); confetti(m, 50); render(); };
      p.append(header(), b); return;
    }
    accrue(); checkAch(); const tabs = h('div', 'sc-tabs'), body = h('div', 'sc-b'); p.append(header(), tabs, body);
    ['Opstelling', 'Kaarten', 'Docenten', 'Prestaties', 'Ranglijst'].forEach((t, i) => { const b = h('button', i === tab ? 'on' : '', t); b.onclick = () => { tab = i; pick = -1; fresh = true; render(); }; tabs.append(b); });
    const opened = Object.entries(S.cards).filter(([, c]) => c.opened), fm = S.club.formation || '4-3-3';
    if (tab === 0) {
      const wrap = h('div', 'sc-split'), pw = h('div', 'pitch-w'), pitch = h('div', 'pitch'), turf = h('div', 'turf'); ['o', 'h', 'c', 'b1', 'b2', 'g1', 'g2'].forEach(c => turf.append(h('div', 'pl ' + c))); turf.append(h('div', 'fl l'), h('div', 'fl r')); pitch.append(turf);
      const P = POS(fm), ch = chemOf(), svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', '0 0 100 100'); svg.setAttribute('preserveAspectRatio', 'none'); svg.setAttribute('class', 'lk');
      LINKS(fm).forEach(([a, b]) => { if (!S.cards[S.club.lineup[a]] || !S.cards[S.club.lineup[b]]) return; const ln = document.createElementNS(NS, 'line'); ln.setAttribute('x1', P[a].x * 100); ln.setAttribute('y1', P[a].y); ln.setAttribute('x2', P[b].x * 100); ln.setAttribute('y2', P[b].y); if (strong(fm, a, b)) ln.setAttribute('class', 'on'); svg.append(ln); });
      pitch.append(svg); const ob = h('div', 'ovr'); ob.append(h('small', '', 'OVR'), h('b', '', ovr())); pitch.append(ob);
      // scouting-balk: hover over een speler voor details
      const pv = h('div', 'sc-pv'), hint = () => { pv.className = 'sc-pv'; pv.replaceChildren(h('div', 'sc-mut', 'Klik op een plek in het veld om een kaart te kiezen. Hoger cijfer en zwaardere weging = meer punten per minuut. Groene lijnen = chemie: kaarten van dezelfde docent naast elkaar geven bonus!')); };
      const scout = (c, idx) => { pv.className = 'sc-pv sp-rar-' + rar(c.grade); const t = h('div', 'pt'); t.append(h('b', '', c.vak), h('span', '', c.onderwerp), h('span', '', 'Docent ' + (docOf(c) || '-') + ' · weging ' + c.weging), h('span', 'r', RN[rar(c.grade)] + ' · ' + ppm(c) + ' pnt/min · chemie ' + ((idx >= 0 && ch.per[idx]) || 0) + '/3')); pv.replaceChildren(h('div', 'pg', c.grade), t); };
      hint();
      P.forEach((q, idx) => {
        const c = S.cards[S.club.lineup[idx]], dr = c && (dropAll || dropIdx === idx), s = h('div', 'sc-slot' + (c ? ' f sp-rar-' + rar(c.grade) : '') + (pick === idx ? ' sel' : '') + (fresh ? ' enter' : '') + (dr ? ' drop' : ''));
        s.style.left = q.x * 100 + '%'; s.style.top = q.y + '%'; if (fresh || dr) s.style.animationDelay = (dropAll ? idx * 110 : fresh ? idx * 90 : 0) + 'ms';
        if (c) { s.append(h('b', '', c.grade), fz(h('span', '', c.vak), fit(10, c.vak, 8)), h('em', '', ppm(c) + '/min'), h('i', 'dc', docOf(c) || '-')); if (ch.per[idx]) s.append(h('u', 'ck', '●'.repeat(ch.per[idx]))); if (dr) s.append(h('i', 'pr')); s.addEventListener('mouseenter', () => scout(c, idx)); s.addEventListener('mouseleave', hint); s.onclick = () => { S.club.lineup[idx] = null; save(); sfx(500, .1, .04, 'triangle', 300); render(); }; }
        else { s.append(h('b', '', '+')); s.onclick = () => { pick = idx; render(); }; } pitch.append(tilt(s, 22, 22));
      });
      pw.append(pitch);
      const side = h('div', 'sc-side2'), tiles = h('div', 'sc-tiles'), tiles2 = h('div', 'sc-tiles t2'), tile = (l, v, c_ = '') => { const d = h('div', 'sc-tile'); d.append(h('div', 'l', l), h('div', 'v ' + c_, v)); return tilt(d, 12); }, cm = chemMult();
      tiles.append(tile('PUNTEN', Math.floor(S.club.points), 'pts'), tile('PER MIN', total()), tile('BONUS', '+' + Math.round((mult() * cm - 1) * 100) + '%'));
      tiles2.append(tile('TEAM OVR', ovr(), 'gold'), tile('CHEMIE', ch.n + ' links · +' + Math.round((cm - 1) * 100) + '%', 'sm'), tile('STREAK', (S.club.streak || 0) + ' dg', 'sm'));
      if (fresh) [ob.lastChild, tiles2.querySelector('.v')].forEach(e => countUp(e, +e.textContent));
      const up = h('button', 'sc-btn p', `Upgrade naar level ${S.club.level + 1} · ${upCost()} pnt`), bar = h('div', 'bar'), fr = h('div', 'sc-form'); bar.append(h('i')); bar.firstChild.style.width = Math.min(100, S.club.points / upCost() * 100) + '%'; up.disabled = S.club.points < upCost();
      up.onclick = () => { accrue(); if (S.club.points >= upCost()) { S.club.points -= upCost(); S.club.level++; save(); [523, 659, 784, 1047].forEach((f, k2) => setTimeout(() => sfx(f, .25, .05, 'triangle'), k2 * 90)); banner('LEVEL ' + S.club.level + ' · ' + rank(S.club.level).toUpperCase()); confetti(m, 70); render(); } };
      Object.keys(FORM).forEach(f => { const b = h('button', 'sc-btn sm' + (f === fm ? ' p' : ''), f); b.onclick = () => { S.club.formation = f; save(); render(); }; fr.append(b); });
      const auto = h('button', 'sc-btn sm', '⚡ Auto'), pres = h('button', 'sc-btn sm', '▶ Teampresentatie'); auto.title = 'Beste kaarten, docenten naast elkaar voor chemie'; pres.disabled = !S.club.lineup.some(Boolean); pres.onclick = () => present(m);
      auto.onclick = () => { const best = [...opened].sort((a, b) => ppm(b[1]) - ppm(a[1])).slice(0, 11).sort((a, b) => (docOf(a[1]) || '~').localeCompare(docOf(b[1]) || '~') || ppm(b[1]) - ppm(a[1])).map(([id]) => id); S.club.lineup = Array.from({ length: 11 }, (_, i) => best[i] || null); save(); dropAll = true; sfx(700, .12, .05, 'triangle', 1100); render(); };
      fr.append(auto, pres);
      const left = claimLeft(), dly = h('button', 'sc-btn p dly', left > 0 ? 'Beloning over ' + fmtT(left) : '🎁 Dagelijkse beloning · +' + claimAmt()); dly.disabled = left > 0;
      dly.onclick = () => { const r = claimDo(); [523, 659, 784, 1047, 1319].forEach((f, k2) => setTimeout(() => sfx(f, .25, .05, 'triangle'), k2 * 80)); confetti(m, 70); toast('🎁 Dagelijkse beloning', '+' + r + ' punten · streak ' + S.club.streak); render(); };
      side.append(tiles, tiles2, bar, up, dly, h('div', 'l', 'FORMATIE'), fr, pv);
      if (pick >= 0) { const l = h('div', 'sc-list'); side.append(h('div', 'l', 'KIES EEN KAART'), l); opened.filter(([id]) => !S.club.lineup.includes(id)).sort((a, b) => num(b[1].grade) - num(a[1].grade)).forEach(([id, c]) => {
        const s = h('div', 'sc-slot f sp-rar-' + rar(c.grade)); s.append(h('b', '', c.grade), fz(h('span', '', c.vak), fit(10, c.vak, 8)), h('em', '', ppm(c) + '/min'), h('i', 'dc', docOf(c) || '-'));
        s.addEventListener('mouseenter', () => scout(c, -1)); s.onclick = () => { S.club.lineup[pick] = id; dropIdx = pick; pick = -1; save(); sfx(500 + rar(c.grade) * 160, .2, .05, 'triangle', 1100 + rar(c.grade) * 200); render(); }; l.append(tilt(s, 24)); });
        if (!l.children.length) l.append(h('span', 'sc-mut', 'Geen vrije kaarten.')); }
      if (!Object.keys(S.rooster).length) side.append(h('div', 'sc-mut', 'Tip: open één keer je rooster, dan worden de docent-afkortingen ingelezen.'));
      wrap.append(pw, side); body.append(wrap); fresh = dropAll = false; dropIdx = -1;
    } else if (tab === 1) {
      const dl = h('button', 'sc-btn p', 'Download kaarten als PNG'), bar = h('div', 'sc-bar2'); dl.onclick = png;
      ['Alles', 'ICON', 'Goud', 'Normaal', 'Onvold.'].forEach((t, i) => { const v = i === 0 ? -1 : 4 - i, b = h('button', 'sc-btn sm' + (v === filt ? ' p' : ''), t); b.onclick = () => { filt = v; render(); }; bar.append(b); });
      const g = h('div', 'sc-cg'); opened.filter(([, c]) => filt < 0 || rar(c.grade) === filt).sort((a, b) => num(b[1].grade) - num(a[1].grade)).forEach(([, c], i) => { const d = cardEl(c); d.style.animation = 'fin .6s backwards'; d.style.animationDelay = i * 60 + 'ms'; g.append(d); });
      if (!g.children.length) g.append(h('span', 'sc-mut', opened.length ? 'Geen kaarten in dit filter.' : 'Nog geen kaarten. Open eerst een pack!')); body.append(dl, bar, g);
    } else if (tab === 2) {
      const grp = {}; opened.forEach(([, c]) => { const d = docOf(c) || '?'; (grp[d] = grp[d] || []).push(c); });
      const avg = a => a.reduce((s, c) => s + num(c.grade), 0) / a.length, ds = Object.entries(grp).sort((a, b) => avg(b[1]) - avg(a[1])), g = h('div', 'sc-docs');
      body.append(h('div', 'sc-mut', 'Per docent: je kaarten en gemiddelde. Zet kaarten van dezelfde docent naast elkaar op het veld voor een chemie-bonus.'), g);
      ds.forEach(([d, cs], i) => { const t = h('div', 'sc-doc'), vs = [...new Set(cs.map(c => c.vak))].join(', '); t.style.animationDelay = i * 70 + 'ms';
        t.append(h('div', 'dcode', d === '?' ? '???' : d), h('div', 'dn', (i === 0 && d !== '?' ? '👑 ' : '') + cs.length + (cs.length === 1 ? ' kaart' : ' kaarten')), h('div', 'da', 'gem. ' + avg(cs).toFixed(1).replace('.', ',') + ' · top ' + cs.reduce((a, c) => (num(c.grade) > num(a.grade) ? c : a)).grade), h('div', 'dv', vs)); g.append(tilt(t, 16)); });
      if (!ds.length) g.append(h('span', 'sc-mut', 'Nog geen kaarten.')); else if (grp['?']) body.append(h('div', 'sc-mut', '??? = docent onbekend. Open je rooster één keer zodat de afkorting wordt ingelezen.'));
    } else if (tab === 3) {
      const done = ACH.filter(a => S.club.ach[a[0]]).length, g = h('div', 'sc-ach'); body.append(h('div', 'sc-mut', done + ' / ' + ACH.length + ' behaald'), g);
      ACH.forEach(([id, t, d, , r], i) => { const ok = S.club.ach[id], el = h('div', 'ach' + (ok ? ' ok' : '')); el.style.animationDelay = i * 40 + 'ms'; el.append(h('div', 'ai', ok ? '🏆' : '🔒'), h('div', 'at', t), h('div', 'ad', d), h('div', 'ar', ok ? 'Behaald' : '+' + r + ' punten')); g.append(tilt(el, 14)); });
    } else {
      const t = h('table', 'sc-tb'), head = '<tr><th>#</th><th>Club</th><th>Level</th><th>Punten</th><th>Per min</th></tr>', note = h('p', 'sc-mut', LB_URL ? 'Online ranglijst wordt geladen…' : 'Rivalen zijn computerclubs. Een online ranglijst met andere spelers werkt zodra er een server is gekoppeld (LB_URL in content.js).');
      const draw = rows => { t.innerHTML = head; rows.forEach((e, i) => { const r = h('tr', e.me ? 'me' : ''); r.style.animationDelay = i * 60 + 'ms'; [['🥇', '🥈', '🥉'][i] || i + 1, e.name + (e.me ? ' (jij)' : ''), e.level, e.points, e.ppm].forEach(v => r.append(h('td', '', v))); t.append(r); }); };
      draw([...botRows(), { name: S.club.name, level: S.club.level, points: Math.floor(S.club.earned || 0), ppm: total(), me: 1 }].sort((a, b) => b.points - a.points)); body.append(t, note);
      if (LB_URL) fetch(LB_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: S.club.name, level: S.club.level, points: Math.floor(S.club.points), ppm: total() }) }).then(r => r.json()).then(list => { draw(list.map(e => ({ ...e, me: e.name === S.club.name }))); note.textContent = ''; }).catch(() => (note.textContent = 'Server niet bereikbaar, rivalen zijn computerclubs.'));
    }
  };
  render();
}

(async () => {
  await load(); accrue();
  FAB = h('button', 'sc-fab', 'Mijn kaarten'); FAB.onclick = club; document.body.append(FAB);
  setInterval(() => { if (S.club) FAB.classList.toggle('dot', claimLeft() <= 0); }, 5000); if (S.club) FAB.classList.toggle('dot', claimLeft() <= 0);
  let tm; new MutationObserver(ms => { if (ms.every(mu => { const t = mu.target.nodeType === 1 ? mu.target : mu.target.parentElement; return t && t.closest && t.closest(OURS); })) return; clearTimeout(tm); tm = setTimeout(decorate, 400); }).observe(document.body, { childList: true, subtree: true }); decorate();
})();
})();
